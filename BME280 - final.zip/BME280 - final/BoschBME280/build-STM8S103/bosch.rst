                                      1 .module bosch
                                      2 .optsdcc -mstm8
                                      3 .globl _delay_ms
                                      4 .globl _I2C_GetFlagStatus
                                      5 .globl _I2C_CheckEvent
                                      6 .globl _I2C_SendData
                                      7 .globl _I2C_Send7bitAddress
                                      8 .globl _I2C_ReceiveData
                                      9 .globl _I2C_AcknowledgeConfig
                                     10 .globl _I2C_GenerateSTOP
                                     11 .globl _I2C_GenerateSTART
                                     12 .globl _I2C_Cmd
                                     13 .globl _I2C_Init
                                     14 .globl _CLK_GetClockFreq
                                     15 .globl __bosch_hashumcalib
                                     16 .globl __bosch_hastempcalib
                                     17 .globl _t_fine
                                     18 .globl __bosch_humcalib
                                     19 .globl __bosch_tempcalib
                                     20 .globl __bosch_address
                                     21 .globl _bosch_Init
                                     22 .globl _bosch_ReadTemp
                                     23 .globl _bosch_ReadTempCalib
                                     24 .globl _bosch_ReadReg
                                     25 .globl _BoschTemp
                                     26 .globl _BoschHum
                                     27 .globl _BoschWrite
                                     28 .area DATA
      000008                         29 __bosch_address::
      000008                         30 .ds 1
      000009                         31 __bosch_tempcalib::
      000009                         32 .ds 6
      00000F                         33 __bosch_humcalib::
      00000F                         34 .ds 9
      000018                         35 _t_fine::
      000018                         36 .ds 4
                                     37 .area INITIALIZED
      00001C                         38 __bosch_hastempcalib::
      00001C                         39 .ds 1
      00001D                         40 __bosch_hashumcalib::
      00001D                         41 .ds 1
                                     42 .area DABS (ABS)
                                     43 .area HOME
                                     44 .area GSINIT
                                     45 .area GSFINAL
                                     46 .area CONST
                                     47 .area INITIALIZER
                                     48 .area CODE
                                     49 .area HOME
                                     50 .area GSINIT
                                     51 .area GSFINAL
                                     52 .area GSINIT
                                     53 .area HOME
                                     54 .area HOME
                                     55 .area CODE
      0082D6                         56 _bosch_Init:
      0082D6 C7 00 08         [ 1]   57 ld	__bosch_address+0, a
      0082D9 72 58 00 08      [ 1]   58 sll	__bosch_address+0
      0082DD CD 8D 14         [ 4]   59 call	_CLK_GetClockFreq
      0082E0 4B 40            [ 1]   60 push	#0x40
      0082E2 4B 42            [ 1]   61 push	#0x42
      0082E4 4B 0F            [ 1]   62 push	#0x0f
      0082E6 4B 00            [ 1]   63 push	#0x00
      0082E8 89               [ 2]   64 pushw	x
      0082E9 90 89            [ 2]   65 pushw	y
      0082EB CD 92 70         [ 4]   66 call	__divulong
      0082EE 5B 08            [ 2]   67 addw	sp, #8
      0082F0 9F               [ 1]   68 ld	a, xl
      0082F1 88               [ 1]   69 push	a
      0082F2 4B 00            [ 1]   70 push	#0x00
      0082F4 4B 01            [ 1]   71 push	#0x01
      0082F6 4B 00            [ 1]   72 push	#0x00
      0082F8 5F               [ 1]   73 clrw	x
      0082F9 89               [ 2]   74 pushw	x
      0082FA 4B A0            [ 1]   75 push	#0xa0
      0082FC 4B 86            [ 1]   76 push	#0x86
      0082FE 4B 01            [ 1]   77 push	#0x01
      008300 4B 00            [ 1]   78 push	#0x00
      008302 CD 8E D9         [ 4]   79 call	_I2C_Init
      008305 A6 01            [ 1]   80 ld	a, #0x01
      008307 CD 90 10         [ 4]   81 call	_I2C_Cmd
      00830A 4B 32            [ 1]   82 push	#0x32
      00830C 5F               [ 1]   83 clrw	x
      00830D 89               [ 2]   84 pushw	x
      00830E 4B 00            [ 1]   85 push	#0x00
      008310 CD 89 DC         [ 4]   86 call	_delay_ms
      008313                         87 00101$:
      008313 81               [ 4]   88 ret
      008314                         89 _bosch_ReadTemp:
      008314 52 03            [ 2]   90 sub	sp, #3
      008316 1F 01            [ 2]   91 ldw	(0x01, sp), x
      008318 A6 03            [ 1]   92 ld	a, #0x03
      00831A 6B 03            [ 1]   93 ld	(0x03, sp), a
      00831C                         94 00101$:
      00831C AE 03 02         [ 2]   95 ldw	x, #0x0302
      00831F CD 91 01         [ 4]   96 call	_I2C_GetFlagStatus
      008322 4D               [ 1]   97 tnz	a
      008323 27 03            [ 1]   98 jreq	00202$
      008325 CC 83 1C         [ 2]   99 jp	00101$
      008328                        100 00202$:
      008328 A6 01            [ 1]  101 ld	a, #0x01
      00832A CD 90 2C         [ 4]  102 call	_I2C_GenerateSTART
      00832D                        103 00104$:
      00832D AE 03 01         [ 2]  104 ldw	x, #0x0301
      008330 CD 90 AC         [ 4]  105 call	_I2C_CheckEvent
      008333 4D               [ 1]  106 tnz	a
      008334 26 03            [ 1]  107 jrne	00203$
      008336 CC 83 2D         [ 2]  108 jp	00104$
      008339                        109 00203$:
      008339 4B 00            [ 1]  110 push	#0x00
      00833B C6 00 08         [ 1]  111 ld	a, __bosch_address+0
      00833E CD 90 9E         [ 4]  112 call	_I2C_Send7bitAddress
      008341                        113 00107$:
      008341 AE 07 82         [ 2]  114 ldw	x, #0x0782
      008344 CD 90 AC         [ 4]  115 call	_I2C_CheckEvent
      008347 4D               [ 1]  116 tnz	a
      008348 26 03            [ 1]  117 jrne	00204$
      00834A CC 83 41         [ 2]  118 jp	00107$
      00834D                        119 00204$:
      00834D A6 FA            [ 1]  120 ld	a, #0xfa
      00834F CD 90 A8         [ 4]  121 call	_I2C_SendData
      008352                        122 00110$:
      008352 AE 07 84         [ 2]  123 ldw	x, #0x0784
      008355 CD 90 AC         [ 4]  124 call	_I2C_CheckEvent
      008358 4D               [ 1]  125 tnz	a
      008359 26 03            [ 1]  126 jrne	00205$
      00835B CC 83 52         [ 2]  127 jp	00110$
      00835E                        128 00205$:
      00835E A6 01            [ 1]  129 ld	a, #0x01
      008360 CD 90 2C         [ 4]  130 call	_I2C_GenerateSTART
      008363                        131 00113$:
      008363 AE 03 01         [ 2]  132 ldw	x, #0x0301
      008366 CD 90 AC         [ 4]  133 call	_I2C_CheckEvent
      008369 4D               [ 1]  134 tnz	a
      00836A 26 03            [ 1]  135 jrne	00206$
      00836C CC 83 63         [ 2]  136 jp	00113$
      00836F                        137 00206$:
      00836F 4B 01            [ 1]  138 push	#0x01
      008371 C6 00 08         [ 1]  139 ld	a, __bosch_address+0
      008374 CD 90 9E         [ 4]  140 call	_I2C_Send7bitAddress
      008377                        141 00116$:
      008377 AE 03 02         [ 2]  142 ldw	x, #0x0302
      00837A CD 90 AC         [ 4]  143 call	_I2C_CheckEvent
      00837D 4D               [ 1]  144 tnz	a
      00837E 26 03            [ 1]  145 jrne	00207$
      008380 CC 83 77         [ 2]  146 jp	00116$
      008383                        147 00207$:
      008383 1E 01            [ 2]  148 ldw	x, (0x01, sp)
      008385                        149 00122$:
      008385 0D 03            [ 1]  150 tnz	(0x03, sp)
      008387 26 03            [ 1]  151 jrne	00208$
      008389 CC 83 A6         [ 2]  152 jp	00124$
      00838C                        153 00208$:
      00838C                        154 00119$:
      00838C 89               [ 2]  155 pushw	x
      00838D AE 01 04         [ 2]  156 ldw	x, #0x0104
      008390 CD 91 01         [ 4]  157 call	_I2C_GetFlagStatus
      008393 85               [ 2]  158 popw	x
      008394 4D               [ 1]  159 tnz	a
      008395 26 03            [ 1]  160 jrne	00209$
      008397 CC 83 8C         [ 2]  161 jp	00119$
      00839A                        162 00209$:
      00839A 89               [ 2]  163 pushw	x
      00839B CD 90 9A         [ 4]  164 call	_I2C_ReceiveData
      00839E 85               [ 2]  165 popw	x
      00839F F7               [ 1]  166 ld	(x), a
      0083A0 5C               [ 1]  167 incw	x
      0083A1 0A 03            [ 1]  168 dec	(0x03, sp)
      0083A3 CC 83 85         [ 2]  169 jp	00122$
      0083A6                        170 00124$:
      0083A6 4F               [ 1]  171 clr	a
      0083A7 CD 90 64         [ 4]  172 call	_I2C_AcknowledgeConfig
      0083AA A6 01            [ 1]  173 ld	a, #0x01
      0083AC 5B 03            [ 2]  174 addw	sp, #3
      0083AE CC 90 48         [ 2]  175 jp	_I2C_GenerateSTOP
      0083B1                        176 00125$:
      0083B1 5B 03            [ 2]  177 addw	sp, #3
      0083B3 81               [ 4]  178 ret
      0083B4                        179 _bosch_ReadTempCalib:
      0083B4 52 03            [ 2]  180 sub	sp, #3
      0083B6 1F 01            [ 2]  181 ldw	(0x01, sp), x
      0083B8 A6 06            [ 1]  182 ld	a, #0x06
      0083BA 6B 03            [ 1]  183 ld	(0x03, sp), a
      0083BC                        184 00101$:
      0083BC AE 03 02         [ 2]  185 ldw	x, #0x0302
      0083BF CD 91 01         [ 4]  186 call	_I2C_GetFlagStatus
      0083C2 4D               [ 1]  187 tnz	a
      0083C3 27 03            [ 1]  188 jreq	00202$
      0083C5 CC 83 BC         [ 2]  189 jp	00101$
      0083C8                        190 00202$:
      0083C8 A6 01            [ 1]  191 ld	a, #0x01
      0083CA CD 90 2C         [ 4]  192 call	_I2C_GenerateSTART
      0083CD                        193 00104$:
      0083CD AE 03 01         [ 2]  194 ldw	x, #0x0301
      0083D0 CD 90 AC         [ 4]  195 call	_I2C_CheckEvent
      0083D3 4D               [ 1]  196 tnz	a
      0083D4 26 03            [ 1]  197 jrne	00203$
      0083D6 CC 83 CD         [ 2]  198 jp	00104$
      0083D9                        199 00203$:
      0083D9 4B 00            [ 1]  200 push	#0x00
      0083DB C6 00 08         [ 1]  201 ld	a, __bosch_address+0
      0083DE CD 90 9E         [ 4]  202 call	_I2C_Send7bitAddress
      0083E1                        203 00107$:
      0083E1 AE 07 82         [ 2]  204 ldw	x, #0x0782
      0083E4 CD 90 AC         [ 4]  205 call	_I2C_CheckEvent
      0083E7 4D               [ 1]  206 tnz	a
      0083E8 26 03            [ 1]  207 jrne	00204$
      0083EA CC 83 E1         [ 2]  208 jp	00107$
      0083ED                        209 00204$:
      0083ED A6 88            [ 1]  210 ld	a, #0x88
      0083EF CD 90 A8         [ 4]  211 call	_I2C_SendData
      0083F2                        212 00110$:
      0083F2 AE 07 84         [ 2]  213 ldw	x, #0x0784
      0083F5 CD 90 AC         [ 4]  214 call	_I2C_CheckEvent
      0083F8 4D               [ 1]  215 tnz	a
      0083F9 26 03            [ 1]  216 jrne	00205$
      0083FB CC 83 F2         [ 2]  217 jp	00110$
      0083FE                        218 00205$:
      0083FE A6 01            [ 1]  219 ld	a, #0x01
      008400 CD 90 2C         [ 4]  220 call	_I2C_GenerateSTART
      008403                        221 00113$:
      008403 AE 03 01         [ 2]  222 ldw	x, #0x0301
      008406 CD 90 AC         [ 4]  223 call	_I2C_CheckEvent
      008409 4D               [ 1]  224 tnz	a
      00840A 26 03            [ 1]  225 jrne	00206$
      00840C CC 84 03         [ 2]  226 jp	00113$
      00840F                        227 00206$:
      00840F 4B 01            [ 1]  228 push	#0x01
      008411 C6 00 08         [ 1]  229 ld	a, __bosch_address+0
      008414 CD 90 9E         [ 4]  230 call	_I2C_Send7bitAddress
      008417                        231 00116$:
      008417 AE 03 02         [ 2]  232 ldw	x, #0x0302
      00841A CD 90 AC         [ 4]  233 call	_I2C_CheckEvent
      00841D 4D               [ 1]  234 tnz	a
      00841E 26 03            [ 1]  235 jrne	00207$
      008420 CC 84 17         [ 2]  236 jp	00116$
      008423                        237 00207$:
      008423 1E 01            [ 2]  238 ldw	x, (0x01, sp)
      008425                        239 00122$:
      008425 0D 03            [ 1]  240 tnz	(0x03, sp)
      008427 26 03            [ 1]  241 jrne	00208$
      008429 CC 84 46         [ 2]  242 jp	00124$
      00842C                        243 00208$:
      00842C                        244 00119$:
      00842C 89               [ 2]  245 pushw	x
      00842D AE 01 04         [ 2]  246 ldw	x, #0x0104
      008430 CD 91 01         [ 4]  247 call	_I2C_GetFlagStatus
      008433 85               [ 2]  248 popw	x
      008434 4D               [ 1]  249 tnz	a
      008435 26 03            [ 1]  250 jrne	00209$
      008437 CC 84 2C         [ 2]  251 jp	00119$
      00843A                        252 00209$:
      00843A 89               [ 2]  253 pushw	x
      00843B CD 90 9A         [ 4]  254 call	_I2C_ReceiveData
      00843E 85               [ 2]  255 popw	x
      00843F F7               [ 1]  256 ld	(x), a
      008440 5C               [ 1]  257 incw	x
      008441 0A 03            [ 1]  258 dec	(0x03, sp)
      008443 CC 84 25         [ 2]  259 jp	00122$
      008446                        260 00124$:
      008446 4F               [ 1]  261 clr	a
      008447 CD 90 64         [ 4]  262 call	_I2C_AcknowledgeConfig
      00844A A6 01            [ 1]  263 ld	a, #0x01
      00844C 5B 03            [ 2]  264 addw	sp, #3
      00844E CC 90 48         [ 2]  265 jp	_I2C_GenerateSTOP
      008451                        266 00125$:
      008451 5B 03            [ 2]  267 addw	sp, #3
      008453 81               [ 4]  268 ret
      008454                        269 _bosch_ReadReg:
      008454 89               [ 2]  270 pushw	x
      008455 6B 01            [ 1]  271 ld	(0x01, sp), a
      008457 A6 01            [ 1]  272 ld	a, #0x01
      008459 6B 02            [ 1]  273 ld	(0x02, sp), a
      00845B                        274 00101$:
      00845B AE 03 02         [ 2]  275 ldw	x, #0x0302
      00845E CD 91 01         [ 4]  276 call	_I2C_GetFlagStatus
      008461 4D               [ 1]  277 tnz	a
      008462 27 03            [ 1]  278 jreq	00202$
      008464 CC 84 5B         [ 2]  279 jp	00101$
      008467                        280 00202$:
      008467 A6 01            [ 1]  281 ld	a, #0x01
      008469 CD 90 2C         [ 4]  282 call	_I2C_GenerateSTART
      00846C                        283 00104$:
      00846C AE 03 01         [ 2]  284 ldw	x, #0x0301
      00846F CD 90 AC         [ 4]  285 call	_I2C_CheckEvent
      008472 4D               [ 1]  286 tnz	a
      008473 26 03            [ 1]  287 jrne	00203$
      008475 CC 84 6C         [ 2]  288 jp	00104$
      008478                        289 00203$:
      008478 4B 00            [ 1]  290 push	#0x00
      00847A C6 00 08         [ 1]  291 ld	a, __bosch_address+0
      00847D CD 90 9E         [ 4]  292 call	_I2C_Send7bitAddress
      008480                        293 00107$:
      008480 AE 07 82         [ 2]  294 ldw	x, #0x0782
      008483 CD 90 AC         [ 4]  295 call	_I2C_CheckEvent
      008486 4D               [ 1]  296 tnz	a
      008487 26 03            [ 1]  297 jrne	00204$
      008489 CC 84 80         [ 2]  298 jp	00107$
      00848C                        299 00204$:
      00848C 7B 01            [ 1]  300 ld	a, (0x01, sp)
      00848E CD 90 A8         [ 4]  301 call	_I2C_SendData
      008491                        302 00110$:
      008491 AE 07 84         [ 2]  303 ldw	x, #0x0784
      008494 CD 90 AC         [ 4]  304 call	_I2C_CheckEvent
      008497 4D               [ 1]  305 tnz	a
      008498 26 03            [ 1]  306 jrne	00205$
      00849A CC 84 91         [ 2]  307 jp	00110$
      00849D                        308 00205$:
      00849D A6 01            [ 1]  309 ld	a, #0x01
      00849F CD 90 2C         [ 4]  310 call	_I2C_GenerateSTART
      0084A2                        311 00113$:
      0084A2 AE 03 01         [ 2]  312 ldw	x, #0x0301
      0084A5 CD 90 AC         [ 4]  313 call	_I2C_CheckEvent
      0084A8 4D               [ 1]  314 tnz	a
      0084A9 26 03            [ 1]  315 jrne	00206$
      0084AB CC 84 A2         [ 2]  316 jp	00113$
      0084AE                        317 00206$:
      0084AE 4B 01            [ 1]  318 push	#0x01
      0084B0 C6 00 08         [ 1]  319 ld	a, __bosch_address+0
      0084B3 CD 90 9E         [ 4]  320 call	_I2C_Send7bitAddress
      0084B6                        321 00116$:
      0084B6 AE 03 02         [ 2]  322 ldw	x, #0x0302
      0084B9 CD 90 AC         [ 4]  323 call	_I2C_CheckEvent
      0084BC 4D               [ 1]  324 tnz	a
      0084BD 26 03            [ 1]  325 jrne	00207$
      0084BF CC 84 B6         [ 2]  326 jp	00116$
      0084C2                        327 00207$:
      0084C2 4F               [ 1]  328 clr	a
      0084C3                        329 00122$:
      0084C3 0D 02            [ 1]  330 tnz	(0x02, sp)
      0084C5 26 03            [ 1]  331 jrne	00208$
      0084C7 CC 84 DE         [ 2]  332 jp	00124$
      0084CA                        333 00208$:
      0084CA                        334 00119$:
      0084CA AE 01 04         [ 2]  335 ldw	x, #0x0104
      0084CD CD 91 01         [ 4]  336 call	_I2C_GetFlagStatus
      0084D0 4D               [ 1]  337 tnz	a
      0084D1 26 03            [ 1]  338 jrne	00209$
      0084D3 CC 84 CA         [ 2]  339 jp	00119$
      0084D6                        340 00209$:
      0084D6 CD 90 9A         [ 4]  341 call	_I2C_ReceiveData
      0084D9 0A 02            [ 1]  342 dec	(0x02, sp)
      0084DB CC 84 C3         [ 2]  343 jp	00122$
      0084DE                        344 00124$:
      0084DE 88               [ 1]  345 push	a
      0084DF 4F               [ 1]  346 clr	a
      0084E0 CD 90 64         [ 4]  347 call	_I2C_AcknowledgeConfig
      0084E3 84               [ 1]  348 pop	a
      0084E4 88               [ 1]  349 push	a
      0084E5 A6 01            [ 1]  350 ld	a, #0x01
      0084E7 CD 90 48         [ 4]  351 call	_I2C_GenerateSTOP
      0084EA 84               [ 1]  352 pop	a
      0084EB                        353 00125$:
      0084EB 85               [ 2]  354 popw	x
      0084EC 81               [ 4]  355 ret
      0084ED                        356 _BoschTemp:
      0084ED 52 1B            [ 2]  357 sub	sp, #27
      0084EF 72 5D 00 1C      [ 1]  358 tnz	__bosch_hastempcalib+0
      0084F3 27 03            [ 1]  359 jreq	00110$
      0084F5 CC 85 02         [ 2]  360 jp	00102$
      0084F8                        361 00110$:
      0084F8 AE 00 09         [ 2]  362 ldw	x, #(__bosch_tempcalib+0)
      0084FB CD 83 B4         [ 4]  363 call	_bosch_ReadTempCalib
      0084FE 35 01 00 1C      [ 1]  364 mov	__bosch_hastempcalib+0, #0x01
      008502                        365 00102$:
      008502 C6 00 0A         [ 1]  366 ld	a, __bosch_tempcalib+1
      008505 5F               [ 1]  367 clrw	x
      008506 95               [ 1]  368 ld	xh, a
      008507 0F 19            [ 1]  369 clr	(0x19, sp)
      008509 C6 00 09         [ 1]  370 ld	a, __bosch_tempcalib+0
      00850C 0F 1A            [ 1]  371 clr	(0x1a, sp)
      00850E 1A 19            [ 1]  372 or	a, (0x19, sp)
      008510 97               [ 1]  373 ld	xl, a
      008511 9E               [ 1]  374 ld	a, xh
      008512 1A 1A            [ 1]  375 or	a, (0x1a, sp)
      008514 95               [ 1]  376 ld	xh, a
      008515 51               [ 1]  377 exgw	x, y
      008516 C6 00 0C         [ 1]  378 ld	a, __bosch_tempcalib+3
      008519 5F               [ 1]  379 clrw	x
      00851A 95               [ 1]  380 ld	xh, a
      00851B 0F 19            [ 1]  381 clr	(0x19, sp)
      00851D C6 00 0B         [ 1]  382 ld	a, __bosch_tempcalib+2
      008520 0F 1A            [ 1]  383 clr	(0x1a, sp)
      008522 1A 19            [ 1]  384 or	a, (0x19, sp)
      008524 97               [ 1]  385 ld	xl, a
      008525 9E               [ 1]  386 ld	a, xh
      008526 1A 1A            [ 1]  387 or	a, (0x1a, sp)
      008528 95               [ 1]  388 ld	xh, a
      008529 1F 04            [ 2]  389 ldw	(0x04, sp), x
      00852B C6 00 0E         [ 1]  390 ld	a, __bosch_tempcalib+5
      00852E 5F               [ 1]  391 clrw	x
      00852F 95               [ 1]  392 ld	xh, a
      008530 0F 19            [ 1]  393 clr	(0x19, sp)
      008532 C6 00 0D         [ 1]  394 ld	a, __bosch_tempcalib+4
      008535 0F 1A            [ 1]  395 clr	(0x1a, sp)
      008537 1A 19            [ 1]  396 or	a, (0x19, sp)
      008539 97               [ 1]  397 ld	xl, a
      00853A 9E               [ 1]  398 ld	a, xh
      00853B 1A 1A            [ 1]  399 or	a, (0x1a, sp)
      00853D 95               [ 1]  400 ld	xh, a
      00853E 1F 06            [ 2]  401 ldw	(0x06, sp), x
      008540 90 89            [ 2]  402 pushw	y
      008542 96               [ 1]  403 ldw	x, sp
      008543 1C 00 03         [ 2]  404 addw	x, #3
      008546 CD 83 14         [ 4]  405 call	_bosch_ReadTemp
      008549 90 85            [ 2]  406 popw	y
      00854B 7B 01            [ 1]  407 ld	a, (0x01, sp)
      00854D 97               [ 1]  408 ld	xl, a
      00854E 7B 02            [ 1]  409 ld	a, (0x02, sp)
      008550 6B 1A            [ 1]  410 ld	(0x1a, sp), a
      008552 7B 03            [ 1]  411 ld	a, (0x03, sp)
      008554 6B 1B            [ 1]  412 ld	(0x1b, sp), a
      008556 9F               [ 1]  413 ld	a, xl
      008557 5F               [ 1]  414 clrw	x
      008558 0F 16            [ 1]  415 clr	(0x16, sp)
      00855A 88               [ 1]  416 push	a
      00855B 7B 17            [ 1]  417 ld	a, (0x17, sp)
      00855D 6B 0D            [ 1]  418 ld	(0x0d, sp), a
      00855F 84               [ 1]  419 pop	a
      008560 88               [ 1]  420 push	a
      008561 A6 0C            [ 1]  421 ld	a, #0x0c
      008563                        422 00111$:
      008563 08 01            [ 1]  423 sll	(1, sp)
      008565 59               [ 2]  424 rlcw	x
      008566 09 0D            [ 1]  425 rlc	(0x0d, sp)
      008568 4A               [ 1]  426 dec	a
      008569 26 F8            [ 1]  427 jrne	00111$
      00856B                        428 00112$:
      00856B 84               [ 1]  429 pop	a
      00856C 6B 0F            [ 1]  430 ld	(0x0f, sp), a
      00856E 1F 0D            [ 2]  431 ldw	(0x0d, sp), x
      008570 7B 1A            [ 1]  432 ld	a, (0x1a, sp)
      008572 5F               [ 1]  433 clrw	x
      008573 0F 17            [ 1]  434 clr	(0x17, sp)
      008575 88               [ 1]  435 push	a
      008576 A6 04            [ 1]  436 ld	a, #0x04
      008578                        437 00113$:
      008578 08 01            [ 1]  438 sll	(1, sp)
      00857A 59               [ 2]  439 rlcw	x
      00857B 09 18            [ 1]  440 rlc	(0x18, sp)
      00857D 4A               [ 1]  441 dec	a
      00857E 26 F8            [ 1]  442 jrne	00113$
      008580                        443 00114$:
      008580 84               [ 1]  444 pop	a
      008581 1A 0F            [ 1]  445 or	a, (0x0f, sp)
      008583 6B 13            [ 1]  446 ld	(0x13, sp), a
      008585 9F               [ 1]  447 ld	a, xl
      008586 1A 0E            [ 1]  448 or	a, (0x0e, sp)
      008588 6B 12            [ 1]  449 ld	(0x12, sp), a
      00858A 9E               [ 1]  450 ld	a, xh
      00858B 1A 0D            [ 1]  451 or	a, (0x0d, sp)
      00858D 6B 11            [ 1]  452 ld	(0x11, sp), a
      00858F 7B 17            [ 1]  453 ld	a, (0x17, sp)
      008591 1A 0C            [ 1]  454 or	a, (0x0c, sp)
      008593 0F 1A            [ 1]  455 clr	(0x1a, sp)
      008595 5F               [ 1]  456 clrw	x
      008596 1F 14            [ 2]  457 ldw	(0x14, sp), x
      008598 1E 1A            [ 2]  458 ldw	x, (0x1a, sp)
      00859A 07 14            [ 1]  459 sra	(0x14, sp)
      00859C 06 15            [ 1]  460 rrc	(0x15, sp)
      00859E 56               [ 2]  461 rrcw	x
      00859F 07 14            [ 1]  462 sra	(0x14, sp)
      0085A1 06 15            [ 1]  463 rrc	(0x15, sp)
      0085A3 56               [ 2]  464 rrcw	x
      0085A4 07 14            [ 1]  465 sra	(0x14, sp)
      0085A6 06 15            [ 1]  466 rrc	(0x15, sp)
      0085A8 56               [ 2]  467 rrcw	x
      0085A9 07 14            [ 1]  468 sra	(0x14, sp)
      0085AB 06 15            [ 1]  469 rrc	(0x15, sp)
      0085AD 56               [ 2]  470 rrcw	x
      0085AE 1A 14            [ 1]  471 or	a, (0x14, sp)
      0085B0 6B 18            [ 1]  472 ld	(0x18, sp), a
      0085B2 89               [ 2]  473 pushw	x
      0085B3 7B 15            [ 1]  474 ld	a, (0x15, sp)
      0085B5 1A 02            [ 1]  475 or	a, (2, sp)
      0085B7 85               [ 2]  476 popw	x
      0085B8 97               [ 1]  477 ld	xl, a
      0085B9 89               [ 2]  478 pushw	x
      0085BA 7B 14            [ 1]  479 ld	a, (0x14, sp)
      0085BC 1A 01            [ 1]  480 or	a, (1, sp)
      0085BE 85               [ 2]  481 popw	x
      0085BF 95               [ 1]  482 ld	xh, a
      0085C0 7B 11            [ 1]  483 ld	a, (0x11, sp)
      0085C2 1A 15            [ 1]  484 or	a, (0x15, sp)
      0085C4 6B 19            [ 1]  485 ld	(0x19, sp), a
      0085C6 1F 0A            [ 2]  486 ldw	(0x0a, sp), x
      0085C8 1E 18            [ 2]  487 ldw	x, (0x18, sp)
      0085CA 1F 08            [ 2]  488 ldw	(0x08, sp), x
      0085CC 7B 08            [ 1]  489 ld	a, (0x08, sp)
      0085CE 6B 0C            [ 1]  490 ld	(0x0c, sp), a
      0085D0 1E 0A            [ 2]  491 ldw	x, (0x0a, sp)
      0085D2 7B 09            [ 1]  492 ld	a, (0x09, sp)
      0085D4 07 0C            [ 1]  493 sra	(0x0c, sp)
      0085D6 46               [ 1]  494 rrc	a
      0085D7 56               [ 2]  495 rrcw	x
      0085D8 07 0C            [ 1]  496 sra	(0x0c, sp)
      0085DA 46               [ 1]  497 rrc	a
      0085DB 56               [ 2]  498 rrcw	x
      0085DC 07 0C            [ 1]  499 sra	(0x0c, sp)
      0085DE 46               [ 1]  500 rrc	a
      0085DF 56               [ 2]  501 rrcw	x
      0085E0 1F 0E            [ 2]  502 ldw	(0x0e, sp), x
      0085E2 17 12            [ 2]  503 ldw	(0x12, sp), y
      0085E4 90 5F            [ 1]  504 clrw	y
      0085E6 17 14            [ 2]  505 ldw	(0x14, sp), y
      0085E8 1E 12            [ 2]  506 ldw	x, (0x12, sp)
      0085EA 58               [ 2]  507 sllw	x
      0085EB 09 15            [ 1]  508 rlc	(0x15, sp)
      0085ED 09 14            [ 1]  509 rlc	(0x14, sp)
      0085EF 1F 16            [ 2]  510 ldw	(0x16, sp), x
      0085F1 1E 0E            [ 2]  511 ldw	x, (0x0e, sp)
      0085F3 72 F0 16         [ 2]  512 subw	x, (0x16, sp)
      0085F6 1F 1A            [ 2]  513 ldw	(0x1a, sp), x
      0085F8 12 15            [ 1]  514 sbc	a, (0x15, sp)
      0085FA 6B 19            [ 1]  515 ld	(0x19, sp), a
      0085FC 7B 0C            [ 1]  516 ld	a, (0x0c, sp)
      0085FE 12 14            [ 1]  517 sbc	a, (0x14, sp)
      008600 6B 18            [ 1]  518 ld	(0x18, sp), a
      008602 1E 04            [ 2]  519 ldw	x, (0x04, sp)
      008604 9E               [ 1]  520 ld	a, xh
      008605 49               [ 1]  521 rlc	a
      008606 4F               [ 1]  522 clr	a
      008607 A2 00            [ 1]  523 sbc	a, #0x00
      008609 6B 15            [ 1]  524 ld	(0x15, sp), a
      00860B 6B 14            [ 1]  525 ld	(0x14, sp), a
      00860D 90 89            [ 2]  526 pushw	y
      00860F 89               [ 2]  527 pushw	x
      008610 1E 18            [ 2]  528 ldw	x, (0x18, sp)
      008612 89               [ 2]  529 pushw	x
      008613 1E 20            [ 2]  530 ldw	x, (0x20, sp)
      008615 89               [ 2]  531 pushw	x
      008616 1E 20            [ 2]  532 ldw	x, (0x20, sp)
      008618 89               [ 2]  533 pushw	x
      008619 CD 92 C9         [ 4]  534 call	__mullong
      00861C 5B 08            [ 2]  535 addw	sp, #8
      00861E 17 1A            [ 2]  536 ldw	(0x1a, sp), y
      008620 90 85            [ 2]  537 popw	y
      008622 7B 18            [ 1]  538 ld	a, (0x18, sp)
      008624 6B 14            [ 1]  539 ld	(0x14, sp), a
      008626 7B 19            [ 1]  540 ld	a, (0x19, sp)
      008628 6B 15            [ 1]  541 ld	(0x15, sp), a
      00862A A6 0B            [ 1]  542 ld	a, #0x0b
      00862C                        543 00115$:
      00862C 07 14            [ 1]  544 sra	(0x14, sp)
      00862E 06 15            [ 1]  545 rrc	(0x15, sp)
      008630 56               [ 2]  546 rrcw	x
      008631 4A               [ 1]  547 dec	a
      008632 26 F8            [ 1]  548 jrne	00115$
      008634                        549 00116$:
      008634 1F 16            [ 2]  550 ldw	(0x16, sp), x
      008636 7B 08            [ 1]  551 ld	a, (0x08, sp)
      008638 6B 18            [ 1]  552 ld	(0x18, sp), a
      00863A 1E 0A            [ 2]  553 ldw	x, (0x0a, sp)
      00863C 7B 09            [ 1]  554 ld	a, (0x09, sp)
      00863E 07 18            [ 1]  555 sra	(0x18, sp)
      008640 46               [ 1]  556 rrc	a
      008641 56               [ 2]  557 rrcw	x
      008642 07 18            [ 1]  558 sra	(0x18, sp)
      008644 46               [ 1]  559 rrc	a
      008645 56               [ 2]  560 rrcw	x
      008646 07 18            [ 1]  561 sra	(0x18, sp)
      008648 46               [ 1]  562 rrc	a
      008649 56               [ 2]  563 rrcw	x
      00864A 07 18            [ 1]  564 sra	(0x18, sp)
      00864C 46               [ 1]  565 rrc	a
      00864D 56               [ 2]  566 rrcw	x
      00864E 72 F0 12         [ 2]  567 subw	x, (0x12, sp)
      008651 90 89            [ 2]  568 pushw	y
      008653 12 02            [ 1]  569 sbc	a, (2, sp)
      008655 90 85            [ 2]  570 popw	y
      008657 90 97            [ 1]  571 ld	yl, a
      008659 7B 18            [ 1]  572 ld	a, (0x18, sp)
      00865B 90 89            [ 2]  573 pushw	y
      00865D 12 01            [ 1]  574 sbc	a, (1, sp)
      00865F 90 85            [ 2]  575 popw	y
      008661 90 95            [ 1]  576 ld	yh, a
      008663 89               [ 2]  577 pushw	x
      008664 90 89            [ 2]  578 pushw	y
      008666 89               [ 2]  579 pushw	x
      008667 90 89            [ 2]  580 pushw	y
      008669 CD 92 C9         [ 4]  581 call	__mullong
      00866C 5B 08            [ 2]  582 addw	sp, #8
      00866E A6 0C            [ 1]  583 ld	a, #0x0c
      008670                        584 00117$:
      008670 90 57            [ 2]  585 sraw	y
      008672 56               [ 2]  586 rrcw	x
      008673 4A               [ 1]  587 dec	a
      008674 26 FA            [ 1]  588 jrne	00117$
      008676                        589 00118$:
      008676 1F 1A            [ 2]  590 ldw	(0x1a, sp), x
      008678 17 18            [ 2]  591 ldw	(0x18, sp), y
      00867A 16 06            [ 2]  592 ldw	y, (0x06, sp)
      00867C 5F               [ 1]  593 clrw	x
      00867D 90 5D            [ 2]  594 tnzw	y
      00867F 2A 01            [ 1]  595 jrpl	00119$
      008681 5A               [ 2]  596 decw	x
      008682                        597 00119$:
      008682 90 89            [ 2]  598 pushw	y
      008684 89               [ 2]  599 pushw	x
      008685 1E 1E            [ 2]  600 ldw	x, (0x1e, sp)
      008687 89               [ 2]  601 pushw	x
      008688 1E 1E            [ 2]  602 ldw	x, (0x1e, sp)
      00868A 89               [ 2]  603 pushw	x
      00868B CD 92 C9         [ 4]  604 call	__mullong
      00868E 5B 08            [ 2]  605 addw	sp, #8
      008690 51               [ 1]  606 exgw	x, y
      008691 A6 0E            [ 1]  607 ld	a, #0x0e
      008693                        608 00120$:
      008693 57               [ 2]  609 sraw	x
      008694 90 56            [ 2]  610 rrcw	y
      008696 4A               [ 1]  611 dec	a
      008697 26 FA            [ 1]  612 jrne	00120$
      008699                        613 00121$:
      008699 72 F9 16         [ 2]  614 addw	y, (0x16, sp)
      00869C 9F               [ 1]  615 ld	a, xl
      00869D 19 15            [ 1]  616 adc	a, (0x15, sp)
      00869F 97               [ 1]  617 ld	xl, a
      0086A0 9E               [ 1]  618 ld	a, xh
      0086A1 19 14            [ 1]  619 adc	a, (0x14, sp)
      0086A3 95               [ 1]  620 ld	xh, a
      0086A4 90 CF 00 1A      [ 2]  621 ldw	_t_fine+2, y
      0086A8 CF 00 18         [ 2]  622 ldw	_t_fine+0, x
      0086AB CE 00 1A         [ 2]  623 ldw	x, _t_fine+2
      0086AE 89               [ 2]  624 pushw	x
      0086AF CE 00 18         [ 2]  625 ldw	x, _t_fine+0
      0086B2 89               [ 2]  626 pushw	x
      0086B3 4B 05            [ 1]  627 push	#0x05
      0086B5 5F               [ 1]  628 clrw	x
      0086B6 89               [ 2]  629 pushw	x
      0086B7 4B 00            [ 1]  630 push	#0x00
      0086B9 CD 92 C9         [ 4]  631 call	__mullong
      0086BC 5B 08            [ 2]  632 addw	sp, #8
      0086BE 17 18            [ 2]  633 ldw	(0x18, sp), y
      0086C0 1C 00 80         [ 2]  634 addw	x, #0x0080
      0086C3 16 18            [ 2]  635 ldw	y, (0x18, sp)
      0086C5 24 02            [ 1]  636 jrnc	00122$
      0086C7 90 5C            [ 1]  637 incw	y
      0086C9                        638 00122$:
      0086C9 4F               [ 1]  639 clr	a
      0086CA 90 5D            [ 2]  640 tnzw	y
      0086CC 2A 01            [ 1]  641 jrpl	00123$
      0086CE 4A               [ 1]  642 dec	a
      0086CF                        643 00123$:
      0086CF 90 01            [ 1]  644 rrwa	y
      0086D1 01               [ 1]  645 rrwa	x
      0086D2                        646 00103$:
      0086D2 5B 1B            [ 2]  647 addw	sp, #27
      0086D4 81               [ 4]  648 ret
      0086D5                        649 _BoschHum:
      0086D5 52 17            [ 2]  650 sub	sp, #23
      0086D7 A6 A1            [ 1]  651 ld	a, #0xa1
      0086D9 CD 84 54         [ 4]  652 call	_bosch_ReadReg
      0086DC 6B 01            [ 1]  653 ld	(0x01, sp), a
      0086DE A6 E1            [ 1]  654 ld	a, #0xe1
      0086E0 CD 84 54         [ 4]  655 call	_bosch_ReadReg
      0086E3 5F               [ 1]  656 clrw	x
      0086E4 6B 16            [ 1]  657 ld	(0x16, sp), a
      0086E6 0F 17            [ 1]  658 clr	(0x17, sp)
      0086E8 A6 E2            [ 1]  659 ld	a, #0xe2
      0086EA CD 84 54         [ 4]  660 call	_bosch_ReadReg
      0086ED 5F               [ 1]  661 clrw	x
      0086EE 1A 17            [ 1]  662 or	a, (0x17, sp)
      0086F0 97               [ 1]  663 ld	xl, a
      0086F1 9E               [ 1]  664 ld	a, xh
      0086F2 1A 16            [ 1]  665 or	a, (0x16, sp)
      0086F4 95               [ 1]  666 ld	xh, a
      0086F5 1F 02            [ 2]  667 ldw	(0x02, sp), x
      0086F7 A6 E3            [ 1]  668 ld	a, #0xe3
      0086F9 CD 84 54         [ 4]  669 call	_bosch_ReadReg
      0086FC 6B 04            [ 1]  670 ld	(0x04, sp), a
      0086FE A6 E4            [ 1]  671 ld	a, #0xe4
      008700 CD 84 54         [ 4]  672 call	_bosch_ReadReg
      008703 5F               [ 1]  673 clrw	x
      008704 97               [ 1]  674 ld	xl, a
      008705 58               [ 2]  675 sllw	x
      008706 58               [ 2]  676 sllw	x
      008707 58               [ 2]  677 sllw	x
      008708 58               [ 2]  678 sllw	x
      008709 1F 14            [ 2]  679 ldw	(0x14, sp), x
      00870B A6 E5            [ 1]  680 ld	a, #0xe5
      00870D CD 84 54         [ 4]  681 call	_bosch_ReadReg
      008710 5F               [ 1]  682 clrw	x
      008711 A4 0F            [ 1]  683 and	a, #0x0f
      008713 6B 17            [ 1]  684 ld	(0x17, sp), a
      008715 4F               [ 1]  685 clr	a
      008716 1A 14            [ 1]  686 or	a, (0x14, sp)
      008718 95               [ 1]  687 ld	xh, a
      008719 7B 15            [ 1]  688 ld	a, (0x15, sp)
      00871B 1A 17            [ 1]  689 or	a, (0x17, sp)
      00871D 97               [ 1]  690 ld	xl, a
      00871E 1F 16            [ 2]  691 ldw	(0x16, sp), x
      008720 A6 E6            [ 1]  692 ld	a, #0xe6
      008722 CD 84 54         [ 4]  693 call	_bosch_ReadReg
      008725 5F               [ 1]  694 clrw	x
      008726 97               [ 1]  695 ld	xl, a
      008727 58               [ 2]  696 sllw	x
      008728 58               [ 2]  697 sllw	x
      008729 58               [ 2]  698 sllw	x
      00872A 58               [ 2]  699 sllw	x
      00872B 1F 14            [ 2]  700 ldw	(0x14, sp), x
      00872D A6 E5            [ 1]  701 ld	a, #0xe5
      00872F CD 84 54         [ 4]  702 call	_bosch_ReadReg
      008732 4E               [ 1]  703 swap	a
      008733 A4 0F            [ 1]  704 and	a, #0x0f
      008735 5F               [ 1]  705 clrw	x
      008736 1A 15            [ 1]  706 or	a, (0x15, sp)
      008738 97               [ 1]  707 ld	xl, a
      008739 9E               [ 1]  708 ld	a, xh
      00873A 1A 14            [ 1]  709 or	a, (0x14, sp)
      00873C 95               [ 1]  710 ld	xh, a
      00873D 1F 05            [ 2]  711 ldw	(0x05, sp), x
      00873F A6 E7            [ 1]  712 ld	a, #0xe7
      008741 CD 84 54         [ 4]  713 call	_bosch_ReadReg
      008744 6B 07            [ 1]  714 ld	(0x07, sp), a
      008746 A6 FD            [ 1]  715 ld	a, #0xfd
      008748 CD 84 54         [ 4]  716 call	_bosch_ReadReg
      00874B 88               [ 1]  717 push	a
      00874C A6 FE            [ 1]  718 ld	a, #0xfe
      00874E CD 84 54         [ 4]  719 call	_bosch_ReadReg
      008751 97               [ 1]  720 ld	xl, a
      008752 84               [ 1]  721 pop	a
      008753 95               [ 1]  722 ld	xh, a
      008754 4F               [ 1]  723 clr	a
      008755 0F 13            [ 1]  724 clr	(0x13, sp)
      008757 9F               [ 1]  725 ld	a, xl
      008758 0F 14            [ 1]  726 clr	(0x14, sp)
      00875A 1A 13            [ 1]  727 or	a, (0x13, sp)
      00875C 97               [ 1]  728 ld	xl, a
      00875D 9E               [ 1]  729 ld	a, xh
      00875E 1A 14            [ 1]  730 or	a, (0x14, sp)
      008760 95               [ 1]  731 ld	xh, a
      008761 1F 14            [ 2]  732 ldw	(0x14, sp), x
      008763 5F               [ 1]  733 clrw	x
      008764 1F 12            [ 2]  734 ldw	(0x12, sp), x
      008766 1E 14            [ 2]  735 ldw	x, (0x14, sp)
      008768 A3 80 00         [ 2]  736 cpw	x, #0x8000
      00876B 26 07            [ 1]  737 jrne	00125$
      00876D 1E 12            [ 2]  738 ldw	x, (0x12, sp)
      00876F 26 03            [ 1]  739 jrne	00125$
      008771 CC 87 77         [ 2]  740 jp	00126$
      008774                        741 00125$:
      008774 CC 87 81         [ 2]  742 jp	00102$
      008777                        743 00126$:
      008777 AE 42 3F         [ 2]  744 ldw	x, #0x423f
      00877A 90 AE 00 0F      [ 2]  745 ldw	y, #0x000f
      00877E CC 89 7A         [ 2]  746 jp	00103$
      008781                        747 00102$:
      008781 CE 00 1A         [ 2]  748 ldw	x, _t_fine+2
      008784 1D 2C 00         [ 2]  749 subw	x, #0x2c00
      008787 1F 0A            [ 2]  750 ldw	(0x0a, sp), x
      008789 C6 00 19         [ 1]  751 ld	a, _t_fine+1
      00878C A2 01            [ 1]  752 sbc	a, #0x01
      00878E 6B 09            [ 1]  753 ld	(0x09, sp), a
      008790 C6 00 18         [ 1]  754 ld	a, _t_fine+0
      008793 A2 00            [ 1]  755 sbc	a, #0x00
      008795 6B 08            [ 1]  756 ld	(0x08, sp), a
      008797 1E 14            [ 2]  757 ldw	x, (0x14, sp)
      008799 16 12            [ 2]  758 ldw	y, (0x12, sp)
      00879B A6 0E            [ 1]  759 ld	a, #0x0e
      00879D                        760 00127$:
      00879D 58               [ 2]  761 sllw	x
      00879E 90 59            [ 2]  762 rlcw	y
      0087A0 4A               [ 1]  763 dec	a
      0087A1 26 FA            [ 1]  764 jrne	00127$
      0087A3                        765 00128$:
      0087A3 1F 0E            [ 2]  766 ldw	(0x0e, sp), x
      0087A5 5F               [ 1]  767 clrw	x
      0087A6 0D 16            [ 1]  768 tnz	(0x16, sp)
      0087A8 2A 01            [ 1]  769 jrpl	00129$
      0087AA 5A               [ 2]  770 decw	x
      0087AB                        771 00129$:
      0087AB 1E 16            [ 2]  772 ldw	x, (0x16, sp)
      0087AD 0F 13            [ 1]  773 clr	(0x13, sp)
      0087AF 0F 12            [ 1]  774 clr	(0x12, sp)
      0087B1 A6 04            [ 1]  775 ld	a, #0x04
      0087B3                        776 00130$:
      0087B3 58               [ 2]  777 sllw	x
      0087B4 4A               [ 1]  778 dec	a
      0087B5 26 FC            [ 1]  779 jrne	00130$
      0087B7                        780 00131$:
      0087B7 02               [ 1]  781 rlwa	x
      0087B8 6B 10            [ 1]  782 ld	(0x10, sp), a
      0087BA 01               [ 1]  783 rrwa	x
      0087BB 9F               [ 1]  784 ld	a, xl
      0087BC 1E 0E            [ 2]  785 ldw	x, (0x0e, sp)
      0087BE 72 F0 12         [ 2]  786 subw	x, (0x12, sp)
      0087C1 1F 16            [ 2]  787 ldw	(0x16, sp), x
      0087C3 88               [ 1]  788 push	a
      0087C4 90 9F            [ 1]  789 ld	a, yl
      0087C6 12 01            [ 1]  790 sbc	a, (1, sp)
      0087C8 5B 01            [ 2]  791 addw	sp, #1
      0087CA 90 9E            [ 1]  792 ld	a, yh
      0087CC 12 10            [ 1]  793 sbc	a, (0x10, sp)
      0087CE 6B 14            [ 1]  794 ld	(0x14, sp), a
      0087D0 16 05            [ 2]  795 ldw	y, (0x05, sp)
      0087D2 17 12            [ 2]  796 ldw	(0x12, sp), y
      0087D4 5F               [ 1]  797 clrw	x
      0087D5 0D 12            [ 1]  798 tnz	(0x12, sp)
      0087D7 2A 01            [ 1]  799 jrpl	00132$
      0087D9 5A               [ 2]  800 decw	x
      0087DA                        801 00132$:
      0087DA 88               [ 1]  802 push	a
      0087DB 16 0B            [ 2]  803 ldw	y, (0x0b, sp)
      0087DD 90 89            [ 2]  804 pushw	y
      0087DF 16 0B            [ 2]  805 ldw	y, (0x0b, sp)
      0087E1 90 89            [ 2]  806 pushw	y
      0087E3 16 17            [ 2]  807 ldw	y, (0x17, sp)
      0087E5 90 89            [ 2]  808 pushw	y
      0087E7 89               [ 2]  809 pushw	x
      0087E8 CD 92 C9         [ 4]  810 call	__mullong
      0087EB 5B 08            [ 2]  811 addw	sp, #8
      0087ED 1F 0F            [ 2]  812 ldw	(0x0f, sp), x
      0087EF 17 0D            [ 2]  813 ldw	(0x0d, sp), y
      0087F1 84               [ 1]  814 pop	a
      0087F2 1E 16            [ 2]  815 ldw	x, (0x16, sp)
      0087F4 72 F0 0E         [ 2]  816 subw	x, (0x0e, sp)
      0087F7 12 0D            [ 1]  817 sbc	a, (0x0d, sp)
      0087F9 6B 11            [ 1]  818 ld	(0x11, sp), a
      0087FB 7B 14            [ 1]  819 ld	a, (0x14, sp)
      0087FD 12 0C            [ 1]  820 sbc	a, (0x0c, sp)
      0087FF 6B 10            [ 1]  821 ld	(0x10, sp), a
      008801 1C 40 00         [ 2]  822 addw	x, #0x4000
      008804 16 10            [ 2]  823 ldw	y, (0x10, sp)
      008806 24 02            [ 1]  824 jrnc	00133$
      008808 90 5C            [ 1]  825 incw	y
      00880A                        826 00133$:
      00880A A6 0F            [ 1]  827 ld	a, #0x0f
      00880C                        828 00134$:
      00880C 90 57            [ 2]  829 sraw	y
      00880E 56               [ 2]  830 rrcw	x
      00880F 4A               [ 1]  831 dec	a
      008810 26 FA            [ 1]  832 jrne	00134$
      008812                        833 00135$:
      008812 1F 16            [ 2]  834 ldw	(0x16, sp), x
      008814 17 14            [ 2]  835 ldw	(0x14, sp), y
      008816 7B 07            [ 1]  836 ld	a, (0x07, sp)
      008818 97               [ 1]  837 ld	xl, a
      008819 9F               [ 1]  838 ld	a, xl
      00881A 49               [ 1]  839 rlc	a
      00881B 4F               [ 1]  840 clr	a
      00881C A2 00            [ 1]  841 sbc	a, #0x00
      00881E 95               [ 1]  842 ld	xh, a
      00881F 90 97            [ 1]  843 ld	yl, a
      008821 90 95            [ 1]  844 ld	yh, a
      008823 89               [ 2]  845 pushw	x
      008824 90 89            [ 2]  846 pushw	y
      008826 1E 0E            [ 2]  847 ldw	x, (0x0e, sp)
      008828 89               [ 2]  848 pushw	x
      008829 1E 0E            [ 2]  849 ldw	x, (0x0e, sp)
      00882B 89               [ 2]  850 pushw	x
      00882C CD 92 C9         [ 4]  851 call	__mullong
      00882F 5B 08            [ 2]  852 addw	sp, #8
      008831 4F               [ 1]  853 clr	a
      008832 90 5D            [ 2]  854 tnzw	y
      008834 2A 01            [ 1]  855 jrpl	00136$
      008836 4A               [ 1]  856 dec	a
      008837                        857 00136$:
      008837 90 01            [ 1]  858 rrwa	y
      008839 01               [ 1]  859 rrwa	x
      00883A 90 57            [ 2]  860 sraw	y
      00883C 56               [ 2]  861 rrcw	x
      00883D 90 57            [ 2]  862 sraw	y
      00883F 56               [ 2]  863 rrcw	x
      008840 1F 12            [ 2]  864 ldw	(0x12, sp), x
      008842 17 10            [ 2]  865 ldw	(0x10, sp), y
      008844 5F               [ 1]  866 clrw	x
      008845 7B 04            [ 1]  867 ld	a, (0x04, sp)
      008847 97               [ 1]  868 ld	xl, a
      008848 90 5F            [ 1]  869 clrw	y
      00884A 89               [ 2]  870 pushw	x
      00884B 90 89            [ 2]  871 pushw	y
      00884D 1E 0E            [ 2]  872 ldw	x, (0x0e, sp)
      00884F 89               [ 2]  873 pushw	x
      008850 1E 0E            [ 2]  874 ldw	x, (0x0e, sp)
      008852 89               [ 2]  875 pushw	x
      008853 CD 92 C9         [ 4]  876 call	__mullong
      008856 5B 08            [ 2]  877 addw	sp, #8
      008858 A6 0B            [ 1]  878 ld	a, #0x0b
      00885A                        879 00137$:
      00885A 90 57            [ 2]  880 sraw	y
      00885C 56               [ 2]  881 rrcw	x
      00885D 4A               [ 1]  882 dec	a
      00885E 26 FA            [ 1]  883 jrne	00137$
      008860                        884 00138$:
      008860 17 0C            [ 2]  885 ldw	(0x0c, sp), y
      008862 1C 80 00         [ 2]  886 addw	x, #0x8000
      008865 16 0C            [ 2]  887 ldw	y, (0x0c, sp)
      008867 24 02            [ 1]  888 jrnc	00139$
      008869 90 5C            [ 1]  889 incw	y
      00886B                        890 00139$:
      00886B 89               [ 2]  891 pushw	x
      00886C 90 89            [ 2]  892 pushw	y
      00886E 1E 16            [ 2]  893 ldw	x, (0x16, sp)
      008870 89               [ 2]  894 pushw	x
      008871 1E 16            [ 2]  895 ldw	x, (0x16, sp)
      008873 89               [ 2]  896 pushw	x
      008874 CD 92 C9         [ 4]  897 call	__mullong
      008877 5B 08            [ 2]  898 addw	sp, #8
      008879 51               [ 1]  899 exgw	x, y
      00887A 4F               [ 1]  900 clr	a
      00887B 5D               [ 2]  901 tnzw	x
      00887C 2A 01            [ 1]  902 jrpl	00140$
      00887E 4A               [ 1]  903 dec	a
      00887F                        904 00140$:
      00887F 01               [ 1]  905 rrwa	x
      008880 90 01            [ 1]  906 rrwa	y
      008882 57               [ 2]  907 sraw	x
      008883 90 56            [ 2]  908 rrcw	y
      008885 57               [ 2]  909 sraw	x
      008886 90 56            [ 2]  910 rrcw	y
      008888 1C 00 20         [ 2]  911 addw	x, #0x0020
      00888B 1F 0C            [ 2]  912 ldw	(0x0c, sp), x
      00888D 1E 02            [ 2]  913 ldw	x, (0x02, sp)
      00888F 9E               [ 1]  914 ld	a, xh
      008890 49               [ 1]  915 rlc	a
      008891 4F               [ 1]  916 clr	a
      008892 A2 00            [ 1]  917 sbc	a, #0x00
      008894 6B 11            [ 1]  918 ld	(0x11, sp), a
      008896 6B 10            [ 1]  919 ld	(0x10, sp), a
      008898 89               [ 2]  920 pushw	x
      008899 1E 12            [ 2]  921 ldw	x, (0x12, sp)
      00889B 89               [ 2]  922 pushw	x
      00889C 90 89            [ 2]  923 pushw	y
      00889E 1E 12            [ 2]  924 ldw	x, (0x12, sp)
      0088A0 89               [ 2]  925 pushw	x
      0088A1 CD 92 C9         [ 4]  926 call	__mullong
      0088A4 5B 08            [ 2]  927 addw	sp, #8
      0088A6 17 10            [ 2]  928 ldw	(0x10, sp), y
      0088A8 1C 20 00         [ 2]  929 addw	x, #0x2000
      0088AB 16 10            [ 2]  930 ldw	y, (0x10, sp)
      0088AD 24 02            [ 1]  931 jrnc	00141$
      0088AF 90 5C            [ 1]  932 incw	y
      0088B1                        933 00141$:
      0088B1 A6 0E            [ 1]  934 ld	a, #0x0e
      0088B3                        935 00142$:
      0088B3 90 57            [ 2]  936 sraw	y
      0088B5 56               [ 2]  937 rrcw	x
      0088B6 4A               [ 1]  938 dec	a
      0088B7 26 FA            [ 1]  939 jrne	00142$
      0088B9                        940 00143$:
      0088B9 89               [ 2]  941 pushw	x
      0088BA 90 89            [ 2]  942 pushw	y
      0088BC 1E 1A            [ 2]  943 ldw	x, (0x1a, sp)
      0088BE 89               [ 2]  944 pushw	x
      0088BF 1E 1A            [ 2]  945 ldw	x, (0x1a, sp)
      0088C1 89               [ 2]  946 pushw	x
      0088C2 CD 92 C9         [ 4]  947 call	__mullong
      0088C5 5B 08            [ 2]  948 addw	sp, #8
      0088C7 90 9E            [ 1]  949 ld	a, yh
      0088C9 1F 0E            [ 2]  950 ldw	(0x0e, sp), x
      0088CB 6B 0C            [ 1]  951 ld	(0x0c, sp), a
      0088CD 90 9F            [ 1]  952 ld	a, yl
      0088CF 88               [ 1]  953 push	a
      0088D0 6B 16            [ 1]  954 ld	(0x16, sp), a
      0088D2 7B 0D            [ 1]  955 ld	a, (0x0d, sp)
      0088D4 6B 15            [ 1]  956 ld	(0x15, sp), a
      0088D6 1E 0F            [ 2]  957 ldw	x, (0x0f, sp)
      0088D8 A6 0F            [ 1]  958 ld	a, #0x0f
      0088DA                        959 00144$:
      0088DA 07 15            [ 1]  960 sra	(0x15, sp)
      0088DC 06 16            [ 1]  961 rrc	(0x16, sp)
      0088DE 56               [ 2]  962 rrcw	x
      0088DF 4A               [ 1]  963 dec	a
      0088E0 26 F8            [ 1]  964 jrne	00144$
      0088E2                        965 00145$:
      0088E2 84               [ 1]  966 pop	a
      0088E3 88               [ 1]  967 push	a
      0088E4 89               [ 2]  968 pushw	x
      0088E5 16 17            [ 2]  969 ldw	y, (0x17, sp)
      0088E7 90 89            [ 2]  970 pushw	y
      0088E9 89               [ 2]  971 pushw	x
      0088EA 1E 1B            [ 2]  972 ldw	x, (0x1b, sp)
      0088EC 89               [ 2]  973 pushw	x
      0088ED CD 92 C9         [ 4]  974 call	__mullong
      0088F0 5B 08            [ 2]  975 addw	sp, #8
      0088F2 84               [ 1]  976 pop	a
      0088F3 88               [ 1]  977 push	a
      0088F4 4F               [ 1]  978 clr	a
      0088F5 90 5D            [ 2]  979 tnzw	y
      0088F7 2A 01            [ 1]  980 jrpl	00146$
      0088F9 4A               [ 1]  981 dec	a
      0088FA                        982 00146$:
      0088FA 90 01            [ 1]  983 rrwa	y
      0088FC 01               [ 1]  984 rrwa	x
      0088FD 48               [ 1]  985 sll	a
      0088FE 59               [ 2]  986 rlcw	x
      0088FF 90 59            [ 2]  987 rlcw	y
      008901 84               [ 1]  988 pop	a
      008902 1F 12            [ 2]  989 ldw	(0x12, sp), x
      008904 17 10            [ 2]  990 ldw	(0x10, sp), y
      008906 5F               [ 1]  991 clrw	x
      008907 41               [ 1]  992 exg	a, xl
      008908 7B 01            [ 1]  993 ld	a, (0x01, sp)
      00890A 41               [ 1]  994 exg	a, xl
      00890B 0F 15            [ 1]  995 clr	(0x15, sp)
      00890D 0F 14            [ 1]  996 clr	(0x14, sp)
      00890F 88               [ 1]  997 push	a
      008910 89               [ 2]  998 pushw	x
      008911 1E 17            [ 2]  999 ldw	x, (0x17, sp)
      008913 89               [ 2] 1000 pushw	x
      008914 1E 17            [ 2] 1001 ldw	x, (0x17, sp)
      008916 89               [ 2] 1002 pushw	x
      008917 1E 17            [ 2] 1003 ldw	x, (0x17, sp)
      008919 89               [ 2] 1004 pushw	x
      00891A CD 92 C9         [ 4] 1005 call	__mullong
      00891D 5B 08            [ 2] 1006 addw	sp, #8
      00891F 84               [ 1] 1007 pop	a
      008920 90 57            [ 2] 1008 sraw	y
      008922 56               [ 2] 1009 rrcw	x
      008923 90 57            [ 2] 1010 sraw	y
      008925 56               [ 2] 1011 rrcw	x
      008926 90 57            [ 2] 1012 sraw	y
      008928 56               [ 2] 1013 rrcw	x
      008929 90 57            [ 2] 1014 sraw	y
      00892B 56               [ 2] 1015 rrcw	x
      00892C 1F 16            [ 2] 1016 ldw	(0x16, sp), x
      00892E 17 14            [ 2] 1017 ldw	(0x14, sp), y
      008930 16 0E            [ 2] 1018 ldw	y, (0x0e, sp)
      008932 72 F2 16         [ 2] 1019 subw	y, (0x16, sp)
      008935 12 15            [ 1] 1020 sbc	a, (0x15, sp)
      008937 97               [ 1] 1021 ld	xl, a
      008938 7B 0C            [ 1] 1022 ld	a, (0x0c, sp)
      00893A 12 14            [ 1] 1023 sbc	a, (0x14, sp)
      00893C 95               [ 1] 1024 ld	xh, a
      00893D 17 16            [ 2] 1025 ldw	(0x16, sp), y
      00893F 1F 14            [ 2] 1026 ldw	(0x14, sp), x
      008941 0D 14            [ 1] 1027 tnz	(0x14, sp)
      008943 2B 03            [ 1] 1028 jrmi	00147$
      008945 CC 89 50         [ 2] 1029 jp	00105$
      008948                       1030 00147$:
      008948 5F               [ 1] 1031 clrw	x
      008949 1F 16            [ 2] 1032 ldw	(0x16, sp), x
      00894B 1F 14            [ 2] 1033 ldw	(0x14, sp), x
      00894D CC 89 50         [ 2] 1034 jp	00106$
      008950                       1035 00105$:
      008950                       1036 00106$:
      008950 5F               [ 1] 1037 clrw	x
      008951 13 16            [ 2] 1038 cpw	x, (0x16, sp)
      008953 4F               [ 1] 1039 clr	a
      008954 12 15            [ 1] 1040 sbc	a, (0x15, sp)
      008956 A6 19            [ 1] 1041 ld	a, #0x19
      008958 12 14            [ 1] 1042 sbc	a, (0x14, sp)
      00895A 2F 03            [ 1] 1043 jrslt	00148$
      00895C CC 89 6A         [ 2] 1044 jp	00107$
      00895F                       1045 00148$:
      00895F 5F               [ 1] 1046 clrw	x
      008960 1F 16            [ 2] 1047 ldw	(0x16, sp), x
      008962 AE 19 00         [ 2] 1048 ldw	x, #0x1900
      008965 1F 14            [ 2] 1049 ldw	(0x14, sp), x
      008967 CC 89 6A         [ 2] 1050 jp	00108$
      00896A                       1051 00107$:
      00896A                       1052 00108$:
      00896A 1E 16            [ 2] 1053 ldw	x, (0x16, sp)
      00896C 16 14            [ 2] 1054 ldw	y, (0x14, sp)
      00896E A6 0C            [ 1] 1055 ld	a, #0x0c
      008970                       1056 00149$:
      008970 90 57            [ 2] 1057 sraw	y
      008972 56               [ 2] 1058 rrcw	x
      008973 4A               [ 1] 1059 dec	a
      008974 26 FA            [ 1] 1060 jrne	00149$
      008976                       1061 00150$:
      008976 17 14            [ 2] 1062 ldw	(0x14, sp), y
      008978 16 14            [ 2] 1063 ldw	y, (0x14, sp)
      00897A                       1064 00103$:
      00897A 5B 17            [ 2] 1065 addw	sp, #23
      00897C 81               [ 4] 1066 ret
      00897D                       1067 _BoschWrite:
      00897D 88               [ 1] 1068 push	a
      00897E 6B 01            [ 1] 1069 ld	(0x01, sp), a
      008980                       1070 00101$:
      008980 AE 03 02         [ 2] 1071 ldw	x, #0x0302
      008983 CD 91 01         [ 4] 1072 call	_I2C_GetFlagStatus
      008986 4D               [ 1] 1073 tnz	a
      008987 27 03            [ 1] 1074 jreq	00168$
      008989 CC 89 80         [ 2] 1075 jp	00101$
      00898C                       1076 00168$:
      00898C A6 01            [ 1] 1077 ld	a, #0x01
      00898E CD 90 2C         [ 4] 1078 call	_I2C_GenerateSTART
      008991                       1079 00104$:
      008991 AE 03 01         [ 2] 1080 ldw	x, #0x0301
      008994 CD 90 AC         [ 4] 1081 call	_I2C_CheckEvent
      008997 4D               [ 1] 1082 tnz	a
      008998 26 03            [ 1] 1083 jrne	00169$
      00899A CC 89 91         [ 2] 1084 jp	00104$
      00899D                       1085 00169$:
      00899D 4B 00            [ 1] 1086 push	#0x00
      00899F C6 00 08         [ 1] 1087 ld	a, __bosch_address+0
      0089A2 CD 90 9E         [ 4] 1088 call	_I2C_Send7bitAddress
      0089A5                       1089 00107$:
      0089A5 AE 07 82         [ 2] 1090 ldw	x, #0x0782
      0089A8 CD 90 AC         [ 4] 1091 call	_I2C_CheckEvent
      0089AB 4D               [ 1] 1092 tnz	a
      0089AC 26 03            [ 1] 1093 jrne	00170$
      0089AE CC 89 A5         [ 2] 1094 jp	00107$
      0089B1                       1095 00170$:
      0089B1 7B 04            [ 1] 1096 ld	a, (0x04, sp)
      0089B3 CD 90 A8         [ 4] 1097 call	_I2C_SendData
      0089B6                       1098 00110$:
      0089B6 AE 07 84         [ 2] 1099 ldw	x, #0x0784
      0089B9 CD 90 AC         [ 4] 1100 call	_I2C_CheckEvent
      0089BC 4D               [ 1] 1101 tnz	a
      0089BD 26 03            [ 1] 1102 jrne	00171$
      0089BF CC 89 B6         [ 2] 1103 jp	00110$
      0089C2                       1104 00171$:
      0089C2 7B 01            [ 1] 1105 ld	a, (0x01, sp)
      0089C4 CD 90 A8         [ 4] 1106 call	_I2C_SendData
      0089C7                       1107 00113$:
      0089C7 AE 07 84         [ 2] 1108 ldw	x, #0x0784
      0089CA CD 90 AC         [ 4] 1109 call	_I2C_CheckEvent
      0089CD 4D               [ 1] 1110 tnz	a
      0089CE 26 03            [ 1] 1111 jrne	00172$
      0089D0 CC 89 C7         [ 2] 1112 jp	00113$
      0089D3                       1113 00172$:
      0089D3 A6 01            [ 1] 1114 ld	a, #0x01
      0089D5 CD 90 48         [ 4] 1115 call	_I2C_GenerateSTOP
      0089D8                       1116 00116$:
      0089D8 84               [ 1] 1117 pop	a
      0089D9 85               [ 2] 1118 popw	x
      0089DA 84               [ 1] 1119 pop	a
      0089DB FC               [ 2] 1120 jp	(x)
                                   1121 .area CODE
                                   1122 .area CONST
                                   1123 .area INITIALIZER
      0080D9                       1124 __xinit___bosch_hastempcalib:
      0080D9 00                    1125 .db #0x00	; 0
      0080DA                       1126 __xinit___bosch_hashumcalib:
      0080DA 00                    1127 .db #0x00	; 0
                                   1128 .area CABS (ABS)
