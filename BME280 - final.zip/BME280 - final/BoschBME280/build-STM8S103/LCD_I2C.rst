                                      1 .module LCD_I2C
                                      2 .optsdcc -mstm8
                                      3 .globl _delay_us
                                      4 .globl _delay_ms
                                      5 .globl _I2C_GetFlagStatus
                                      6 .globl _I2C_CheckEvent
                                      7 .globl _I2C_SendData
                                      8 .globl _I2C_Send7bitAddress
                                      9 .globl _I2C_GenerateSTOP
                                     10 .globl _I2C_GenerateSTART
                                     11 .globl _I2C_Cmd
                                     12 .globl _I2C_Init
                                     13 .globl _I2C_DeInit
                                     14 .globl _GPIO_Init
                                     15 .globl _CLK_GetClockFreq
                                     16 .globl __lcd_i2c_displaymode
                                     17 .globl __lcd_i2c_displaycontrol
                                     18 .globl __lcd_i2c_displayfunction
                                     19 .globl __lcd_i2c_backlight
                                     20 .globl __lcd_i2c_rows
                                     21 .globl __lcd_i2c_cols
                                     22 .globl __lcd_i2c_address
                                     23 .globl _LCD_I2C_Init
                                     24 .globl _LCD_I2C_Write
                                     25 .globl _LCD_I2C_ExpanderWrite
                                     26 .globl _LCD_I2C_Write4Bits
                                     27 .globl _LCD_I2C_PulseEnable
                                     28 .globl _LCD_I2C_Command
                                     29 .globl _LCD_I2C_Send
                                     30 .globl _LCD_I2C_Display
                                     31 .globl _LCD_I2C_Clear
                                     32 .globl _LCD_I2C_Home
                                     33 .globl _LCD_I2C_SetCursor
                                     34 .globl _LCD_I2C_Print
                                     35 .area DATA
      000001                         36 __lcd_i2c_address::
      000001                         37 .ds 1
      000002                         38 __lcd_i2c_cols::
      000002                         39 .ds 1
      000003                         40 __lcd_i2c_rows::
      000003                         41 .ds 1
      000004                         42 __lcd_i2c_backlight::
      000004                         43 .ds 1
      000005                         44 __lcd_i2c_displayfunction::
      000005                         45 .ds 1
      000006                         46 __lcd_i2c_displaycontrol::
      000006                         47 .ds 1
      000007                         48 __lcd_i2c_displaymode::
      000007                         49 .ds 1
                                     50 .area INITIALIZED
                                     51 .area DABS (ABS)
                                     52 .area HOME
                                     53 .area GSINIT
                                     54 .area GSFINAL
                                     55 .area CONST
                                     56 .area INITIALIZER
                                     57 .area CODE
                                     58 .area HOME
                                     59 .area GSINIT
                                     60 .area GSFINAL
                                     61 .area GSINIT
                                     62 .area HOME
                                     63 .area HOME
                                     64 .area CODE
      0080DF                         65 _LCD_I2C_Init:
      0080DF C7 00 01         [ 1]   66 ld	__lcd_i2c_address+0, a
      0080E2 72 58 00 01      [ 1]   67 sll	__lcd_i2c_address+0
      0080E6 7B 03            [ 1]   68 ld	a, (0x03, sp)
      0080E8 C7 00 02         [ 1]   69 ld	__lcd_i2c_cols+0, a
      0080EB 7B 04            [ 1]   70 ld	a, (0x04, sp)
      0080ED C7 00 03         [ 1]   71 ld	__lcd_i2c_rows+0, a
      0080F0 35 08 00 04      [ 1]   72 mov	__lcd_i2c_backlight+0, #0x08
      0080F4 35 08 00 05      [ 1]   73 mov	__lcd_i2c_displayfunction+0, #0x08
      0080F8 4B F0            [ 1]   74 push	#0xf0
      0080FA A6 20            [ 1]   75 ld	a, #0x20
      0080FC AE 50 05         [ 2]   76 ldw	x, #0x5005
      0080FF CD 8C 56         [ 4]   77 call	_GPIO_Init
      008102 4B F0            [ 1]   78 push	#0xf0
      008104 A6 10            [ 1]   79 ld	a, #0x10
      008106 AE 50 05         [ 2]   80 ldw	x, #0x5005
      008109 CD 8C 56         [ 4]   81 call	_GPIO_Init
      00810C CD 8E B4         [ 4]   82 call	_I2C_DeInit
      00810F CD 8D 14         [ 4]   83 call	_CLK_GetClockFreq
      008112 4B 40            [ 1]   84 push	#0x40
      008114 4B 42            [ 1]   85 push	#0x42
      008116 4B 0F            [ 1]   86 push	#0x0f
      008118 4B 00            [ 1]   87 push	#0x00
      00811A 89               [ 2]   88 pushw	x
      00811B 90 89            [ 2]   89 pushw	y
      00811D CD 92 70         [ 4]   90 call	__divulong
      008120 5B 08            [ 2]   91 addw	sp, #8
      008122 9F               [ 1]   92 ld	a, xl
      008123 5F               [ 1]   93 clrw	x
      008124 41               [ 1]   94 exg	a, xl
      008125 C6 00 01         [ 1]   95 ld	a, __lcd_i2c_address+0
      008128 41               [ 1]   96 exg	a, xl
      008129 88               [ 1]   97 push	a
      00812A 4B 00            [ 1]   98 push	#0x00
      00812C 4B 01            [ 1]   99 push	#0x01
      00812E 4B 00            [ 1]  100 push	#0x00
      008130 89               [ 2]  101 pushw	x
      008131 4B A0            [ 1]  102 push	#0xa0
      008133 4B 86            [ 1]  103 push	#0x86
      008135 4B 01            [ 1]  104 push	#0x01
      008137 4B 00            [ 1]  105 push	#0x00
      008139 CD 8E D9         [ 4]  106 call	_I2C_Init
      00813C A6 01            [ 1]  107 ld	a, #0x01
      00813E CD 90 10         [ 4]  108 call	_I2C_Cmd
      008141 4B 32            [ 1]  109 push	#0x32
      008143 5F               [ 1]  110 clrw	x
      008144 89               [ 2]  111 pushw	x
      008145 4B 00            [ 1]  112 push	#0x00
      008147 CD 89 DC         [ 4]  113 call	_delay_ms
      00814A C6 00 04         [ 1]  114 ld	a, __lcd_i2c_backlight+0
      00814D CD 81 F8         [ 4]  115 call	_LCD_I2C_ExpanderWrite
      008150 4B E8            [ 1]  116 push	#0xe8
      008152 4B 03            [ 1]  117 push	#0x03
      008154 5F               [ 1]  118 clrw	x
      008155 89               [ 2]  119 pushw	x
      008156 CD 89 DC         [ 4]  120 call	_delay_ms
      008159 A6 30            [ 1]  121 ld	a, #0x30
      00815B CD 82 03         [ 4]  122 call	_LCD_I2C_Write4Bits
      00815E 4B 94            [ 1]  123 push	#0x94
      008160 4B 11            [ 1]  124 push	#0x11
      008162 5F               [ 1]  125 clrw	x
      008163 89               [ 2]  126 pushw	x
      008164 CD 8A 44         [ 4]  127 call	_delay_us
      008167 A6 30            [ 1]  128 ld	a, #0x30
      008169 CD 82 03         [ 4]  129 call	_LCD_I2C_Write4Bits
      00816C 4B 94            [ 1]  130 push	#0x94
      00816E 4B 11            [ 1]  131 push	#0x11
      008170 5F               [ 1]  132 clrw	x
      008171 89               [ 2]  133 pushw	x
      008172 CD 8A 44         [ 4]  134 call	_delay_us
      008175 A6 30            [ 1]  135 ld	a, #0x30
      008177 CD 82 03         [ 4]  136 call	_LCD_I2C_Write4Bits
      00817A 4B 96            [ 1]  137 push	#0x96
      00817C 5F               [ 1]  138 clrw	x
      00817D 89               [ 2]  139 pushw	x
      00817E 4B 00            [ 1]  140 push	#0x00
      008180 CD 8A 44         [ 4]  141 call	_delay_us
      008183 A6 20            [ 1]  142 ld	a, #0x20
      008185 CD 82 03         [ 4]  143 call	_LCD_I2C_Write4Bits
      008188 C6 00 05         [ 1]  144 ld	a, __lcd_i2c_displayfunction+0
      00818B AA 20            [ 1]  145 or	a, #0x20
      00818D CD 82 31         [ 4]  146 call	_LCD_I2C_Command
      008190 35 04 00 06      [ 1]  147 mov	__lcd_i2c_displaycontrol+0, #0x04
      008194 CD 82 55         [ 4]  148 call	_LCD_I2C_Display
      008197 CD 82 62         [ 4]  149 call	_LCD_I2C_Clear
      00819A 35 02 00 07      [ 1]  150 mov	__lcd_i2c_displaymode+0, #0x02
      00819E A6 06            [ 1]  151 ld	a, #0x06
      0081A0 CD 82 31         [ 4]  152 call	_LCD_I2C_Command
      0081A3 CD 82 71         [ 4]  153 call	_LCD_I2C_Home
      0081A6                        154 00101$:
      0081A6 1E 01            [ 2]  155 ldw	x, (1, sp)
      0081A8 5B 04            [ 2]  156 addw	sp, #4
      0081AA FC               [ 2]  157 jp	(x)
      0081AB                        158 _LCD_I2C_Write:
      0081AB 88               [ 1]  159 push	a
      0081AC 6B 01            [ 1]  160 ld	(0x01, sp), a
      0081AE                        161 00101$:
      0081AE AE 03 02         [ 2]  162 ldw	x, #0x0302
      0081B1 CD 91 01         [ 4]  163 call	_I2C_GetFlagStatus
      0081B4 4D               [ 1]  164 tnz	a
      0081B5 27 03            [ 1]  165 jreq	00155$
      0081B7 CC 81 AE         [ 2]  166 jp	00101$
      0081BA                        167 00155$:
      0081BA A6 01            [ 1]  168 ld	a, #0x01
      0081BC CD 90 2C         [ 4]  169 call	_I2C_GenerateSTART
      0081BF                        170 00104$:
      0081BF AE 03 01         [ 2]  171 ldw	x, #0x0301
      0081C2 CD 90 AC         [ 4]  172 call	_I2C_CheckEvent
      0081C5 4D               [ 1]  173 tnz	a
      0081C6 26 03            [ 1]  174 jrne	00156$
      0081C8 CC 81 BF         [ 2]  175 jp	00104$
      0081CB                        176 00156$:
      0081CB 4B 00            [ 1]  177 push	#0x00
      0081CD 7B 02            [ 1]  178 ld	a, (0x02, sp)
      0081CF CD 90 9E         [ 4]  179 call	_I2C_Send7bitAddress
      0081D2                        180 00107$:
      0081D2 AE 07 82         [ 2]  181 ldw	x, #0x0782
      0081D5 CD 90 AC         [ 4]  182 call	_I2C_CheckEvent
      0081D8 4D               [ 1]  183 tnz	a
      0081D9 26 03            [ 1]  184 jrne	00157$
      0081DB CC 81 D2         [ 2]  185 jp	00107$
      0081DE                        186 00157$:
      0081DE 7B 04            [ 1]  187 ld	a, (0x04, sp)
      0081E0 CD 90 A8         [ 4]  188 call	_I2C_SendData
      0081E3                        189 00110$:
      0081E3 AE 07 84         [ 2]  190 ldw	x, #0x0784
      0081E6 CD 90 AC         [ 4]  191 call	_I2C_CheckEvent
      0081E9 4D               [ 1]  192 tnz	a
      0081EA 26 03            [ 1]  193 jrne	00158$
      0081EC CC 81 E3         [ 2]  194 jp	00110$
      0081EF                        195 00158$:
      0081EF A6 01            [ 1]  196 ld	a, #0x01
      0081F1 CD 90 48         [ 4]  197 call	_I2C_GenerateSTOP
      0081F4                        198 00113$:
      0081F4 84               [ 1]  199 pop	a
      0081F5 85               [ 2]  200 popw	x
      0081F6 84               [ 1]  201 pop	a
      0081F7 FC               [ 2]  202 jp	(x)
      0081F8                        203 _LCD_I2C_ExpanderWrite:
      0081F8 CA 00 04         [ 1]  204 or	a, __lcd_i2c_backlight+0
      0081FB 88               [ 1]  205 push	a
      0081FC C6 00 01         [ 1]  206 ld	a, __lcd_i2c_address+0
      0081FF CD 81 AB         [ 4]  207 call	_LCD_I2C_Write
      008202                        208 00101$:
      008202 81               [ 4]  209 ret
      008203                        210 _LCD_I2C_Write4Bits:
      008203 88               [ 1]  211 push	a
      008204 CD 81 F8         [ 4]  212 call	_LCD_I2C_ExpanderWrite
      008207 84               [ 1]  213 pop	a
      008208 CC 82 0C         [ 2]  214 jp	_LCD_I2C_PulseEnable
      00820B                        215 00101$:
      00820B 81               [ 4]  216 ret
      00820C                        217 _LCD_I2C_PulseEnable:
      00820C 88               [ 1]  218 push	a
      00820D 6B 01            [ 1]  219 ld	(0x01, sp), a
      00820F 7B 01            [ 1]  220 ld	a, (0x01, sp)
      008211 AA 04            [ 1]  221 or	a, #0x04
      008213 CD 81 F8         [ 4]  222 call	_LCD_I2C_ExpanderWrite
      008216 4B 01            [ 1]  223 push	#0x01
      008218 5F               [ 1]  224 clrw	x
      008219 89               [ 2]  225 pushw	x
      00821A 4B 00            [ 1]  226 push	#0x00
      00821C CD 8A 44         [ 4]  227 call	_delay_us
      00821F 7B 01            [ 1]  228 ld	a, (0x01, sp)
      008221 A4 FB            [ 1]  229 and	a, #0xfb
      008223 CD 81 F8         [ 4]  230 call	_LCD_I2C_ExpanderWrite
      008226 4B 32            [ 1]  231 push	#0x32
      008228 5F               [ 1]  232 clrw	x
      008229 89               [ 2]  233 pushw	x
      00822A 4B 00            [ 1]  234 push	#0x00
      00822C CD 8A 44         [ 4]  235 call	_delay_us
      00822F                        236 00101$:
      00822F 84               [ 1]  237 pop	a
      008230 81               [ 4]  238 ret
      008231                        239 _LCD_I2C_Command:
      008231 4B 00            [ 1]  240 push	#0x00
      008233 CD 82 37         [ 4]  241 call	_LCD_I2C_Send
      008236                        242 00101$:
      008236 81               [ 4]  243 ret
      008237                        244 _LCD_I2C_Send:
      008237 88               [ 1]  245 push	a
      008238 88               [ 1]  246 push	a
      008239 A4 F0            [ 1]  247 and	a, #0xf0
      00823B 97               [ 1]  248 ld	xl, a
      00823C 84               [ 1]  249 pop	a
      00823D 4E               [ 1]  250 swap	a
      00823E A4 F0            [ 1]  251 and	a, #0xf0
      008240 A4 F0            [ 1]  252 and	a, #0xf0
      008242 6B 01            [ 1]  253 ld	(0x01, sp), a
      008244 9F               [ 1]  254 ld	a, xl
      008245 1A 04            [ 1]  255 or	a, (0x04, sp)
      008247 CD 82 03         [ 4]  256 call	_LCD_I2C_Write4Bits
      00824A 7B 01            [ 1]  257 ld	a, (0x01, sp)
      00824C 1A 04            [ 1]  258 or	a, (0x04, sp)
      00824E CD 82 03         [ 4]  259 call	_LCD_I2C_Write4Bits
      008251                        260 00101$:
      008251 84               [ 1]  261 pop	a
      008252 85               [ 2]  262 popw	x
      008253 84               [ 1]  263 pop	a
      008254 FC               [ 2]  264 jp	(x)
      008255                        265 _LCD_I2C_Display:
      008255 72 14 00 06      [ 1]  266 bset	__lcd_i2c_displaycontrol+0, #2
      008259 C6 00 06         [ 1]  267 ld	a, __lcd_i2c_displaycontrol+0
      00825C AA 08            [ 1]  268 or	a, #0x08
      00825E CC 82 31         [ 2]  269 jp	_LCD_I2C_Command
      008261                        270 00101$:
      008261 81               [ 4]  271 ret
      008262                        272 _LCD_I2C_Clear:
      008262 A6 01            [ 1]  273 ld	a, #0x01
      008264 CD 82 31         [ 4]  274 call	_LCD_I2C_Command
      008267 4B D0            [ 1]  275 push	#0xd0
      008269 4B 07            [ 1]  276 push	#0x07
      00826B 5F               [ 1]  277 clrw	x
      00826C 89               [ 2]  278 pushw	x
      00826D CD 8A 44         [ 4]  279 call	_delay_us
      008270                        280 00101$:
      008270 81               [ 4]  281 ret
      008271                        282 _LCD_I2C_Home:
      008271 A6 02            [ 1]  283 ld	a, #0x02
      008273 CD 82 31         [ 4]  284 call	_LCD_I2C_Command
      008276 4B D0            [ 1]  285 push	#0xd0
      008278 4B 07            [ 1]  286 push	#0x07
      00827A 5F               [ 1]  287 clrw	x
      00827B 89               [ 2]  288 pushw	x
      00827C CD 8A 44         [ 4]  289 call	_delay_us
      00827F                        290 00101$:
      00827F 81               [ 4]  291 ret
      008280                        292 _LCD_I2C_SetCursor:
      008280 52 0A            [ 2]  293 sub	sp, #10
      008282 90 97            [ 1]  294 ld	yl, a
      008284 5F               [ 1]  295 clrw	x
      008285 1F 01            [ 2]  296 ldw	(0x01, sp), x
      008287 AE 00 40         [ 2]  297 ldw	x, #0x0040
      00828A 1F 03            [ 2]  298 ldw	(0x03, sp), x
      00828C AE 00 14         [ 2]  299 ldw	x, #0x0014
      00828F 1F 05            [ 2]  300 ldw	(0x05, sp), x
      008291 AE 00 54         [ 2]  301 ldw	x, #0x0054
      008294 1F 07            [ 2]  302 ldw	(0x07, sp), x
      008296 7B 0D            [ 1]  303 ld	a, (0x0d, sp)
      008298 C1 00 03         [ 1]  304 cp	a, __lcd_i2c_rows+0
      00829B 22 03            [ 1]  305 jrugt	00110$
      00829D CC 82 A6         [ 2]  306 jp	00102$
      0082A0                        307 00110$:
      0082A0 C6 00 03         [ 1]  308 ld	a, __lcd_i2c_rows+0
      0082A3 4A               [ 1]  309 dec	a
      0082A4 6B 0D            [ 1]  310 ld	(0x0d, sp), a
      0082A6                        311 00102$:
      0082A6 5F               [ 1]  312 clrw	x
      0082A7 7B 0D            [ 1]  313 ld	a, (0x0d, sp)
      0082A9 97               [ 1]  314 ld	xl, a
      0082AA 58               [ 2]  315 sllw	x
      0082AB 1F 09            [ 2]  316 ldw	(0x09, sp), x
      0082AD 96               [ 1]  317 ldw	x, sp
      0082AE 5C               [ 1]  318 incw	x
      0082AF 72 FB 09         [ 2]  319 addw	x, (0x09, sp)
      0082B2 E6 01            [ 1]  320 ld	a, (0x1, x)
      0082B4 93               [ 1]  321 ldw	x, y
      0082B5 89               [ 2]  322 pushw	x
      0082B6 1B 02            [ 1]  323 add	a, (2, sp)
      0082B8 85               [ 2]  324 popw	x
      0082B9 AA 80            [ 1]  325 or	a, #0x80
      0082BB CD 82 31         [ 4]  326 call	_LCD_I2C_Command
      0082BE                        327 00103$:
      0082BE 5B 0A            [ 2]  328 addw	sp, #10
      0082C0 85               [ 2]  329 popw	x
      0082C1 84               [ 1]  330 pop	a
      0082C2 FC               [ 2]  331 jp	(x)
      0082C3                        332 _LCD_I2C_Print:
      0082C3                        333 00101$:
      0082C3 F6               [ 1]  334 ld	a, (x)
      0082C4 4D               [ 1]  335 tnz	a
      0082C5 26 03            [ 1]  336 jrne	00117$
      0082C7 CC 82 D5         [ 2]  337 jp	00104$
      0082CA                        338 00117$:
      0082CA 89               [ 2]  339 pushw	x
      0082CB 4B 01            [ 1]  340 push	#0x01
      0082CD CD 82 37         [ 4]  341 call	_LCD_I2C_Send
      0082D0 85               [ 2]  342 popw	x
      0082D1 5C               [ 1]  343 incw	x
      0082D2 CC 82 C3         [ 2]  344 jp	00101$
      0082D5                        345 00104$:
      0082D5 81               [ 4]  346 ret
                                    347 .area CODE
                                    348 .area CONST
                                    349 .area INITIALIZER
                                    350 .area CABS (ABS)
