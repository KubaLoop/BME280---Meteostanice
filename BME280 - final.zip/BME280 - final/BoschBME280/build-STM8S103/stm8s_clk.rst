                                      1 .module stm8s_clk
                                      2 .optsdcc -mstm8
                                      3 .globl _HSIDivFactor
                                      4 .globl _CLK_HSIPrescalerConfig
                                      5 .globl _CLK_GetClockFreq
                                      6 .area DATA
                                      7 .area INITIALIZED
                                      8 .area DABS (ABS)
                                      9 .area HOME
                                     10 .area GSINIT
                                     11 .area GSFINAL
                                     12 .area CONST
                                     13 .area INITIALIZER
                                     14 .area CODE
                                     15 .area HOME
                                     16 .area GSINIT
                                     17 .area GSFINAL
                                     18 .area GSINIT
                                     19 .area HOME
                                     20 .area HOME
                                     21 .area CODE
      008CFF                         22 _CLK_HSIPrescalerConfig:
      008CFF 88               [ 1]   23 push	a
      008D00 6B 01            [ 1]   24 ld	(0x01, sp), a
      008D02 C6 50 C6         [ 1]   25 ld	a, 0x50c6
      008D05 A4 E7            [ 1]   26 and	a, #0xe7
      008D07 C7 50 C6         [ 1]   27 ld	0x50c6, a
      008D0A C6 50 C6         [ 1]   28 ld	a, 0x50c6
      008D0D 1A 01            [ 1]   29 or	a, (0x01, sp)
      008D0F C7 50 C6         [ 1]   30 ld	0x50c6, a
      008D12                         31 00101$:
      008D12 84               [ 1]   32 pop	a
      008D13 81               [ 4]   33 ret
      008D14                         34 _CLK_GetClockFreq:
      008D14 52 04            [ 2]   35 sub	sp, #4
      008D16 C6 50 C3         [ 1]   36 ld	a, 0x50c3
      008D19 6B 04            [ 1]   37 ld	(0x04, sp), a
      008D1B 7B 04            [ 1]   38 ld	a, (0x04, sp)
      008D1D A1 E1            [ 1]   39 cp	a, #0xe1
      008D1F 26 03            [ 1]   40 jrne	00120$
      008D21 CC 8D 27         [ 2]   41 jp	00121$
      008D24                         42 00120$:
      008D24 CC 8D 4F         [ 2]   43 jp	00105$
      008D27                         44 00121$:
      008D27 C6 50 C6         [ 1]   45 ld	a, 0x50c6
      008D2A A4 18            [ 1]   46 and	a, #0x18
      008D2C 44               [ 1]   47 srl	a
      008D2D 44               [ 1]   48 srl	a
      008D2E 44               [ 1]   49 srl	a
      008D2F 5F               [ 1]   50 clrw	x
      008D30 97               [ 1]   51 ld	xl, a
      008D31 1C 80 CA         [ 2]   52 addw	x, #(_HSIDivFactor+0)
      008D34 F6               [ 1]   53 ld	a, (x)
      008D35 5F               [ 1]   54 clrw	x
      008D36 97               [ 1]   55 ld	xl, a
      008D37 90 5F            [ 1]   56 clrw	y
      008D39 89               [ 2]   57 pushw	x
      008D3A 90 89            [ 2]   58 pushw	y
      008D3C 4B 00            [ 1]   59 push	#0x00
      008D3E 4B 24            [ 1]   60 push	#0x24
      008D40 4B F4            [ 1]   61 push	#0xf4
      008D42 4B 00            [ 1]   62 push	#0x00
      008D44 CD 92 70         [ 4]   63 call	__divulong
      008D47 5B 08            [ 2]   64 addw	sp, #8
      008D49 51               [ 1]   65 exgw	x, y
      008D4A 17 03            [ 2]   66 ldw	(0x03, sp), y
      008D4C CC 8D 6D         [ 2]   67 jp	00106$
      008D4F                         68 00105$:
      008D4F 7B 04            [ 1]   69 ld	a, (0x04, sp)
      008D51 A1 D2            [ 1]   70 cp	a, #0xd2
      008D53 26 03            [ 1]   71 jrne	00123$
      008D55 CC 8D 5B         [ 2]   72 jp	00124$
      008D58                         73 00123$:
      008D58 CC 8D 65         [ 2]   74 jp	00102$
      008D5B                         75 00124$:
      008D5B AE F4 00         [ 2]   76 ldw	x, #0xf400
      008D5E 1F 03            [ 2]   77 ldw	(0x03, sp), x
      008D60 5F               [ 1]   78 clrw	x
      008D61 5C               [ 1]   79 incw	x
      008D62 CC 8D 6D         [ 2]   80 jp	00106$
      008D65                         81 00102$:
      008D65 AE 24 00         [ 2]   82 ldw	x, #0x2400
      008D68 1F 03            [ 2]   83 ldw	(0x03, sp), x
      008D6A AE 00 F4         [ 2]   84 ldw	x, #0x00f4
      008D6D                         85 00106$:
      008D6D 51               [ 1]   86 exgw	x, y
      008D6E 1E 03            [ 2]   87 ldw	x, (0x03, sp)
      008D70                         88 00107$:
      008D70 5B 04            [ 2]   89 addw	sp, #4
      008D72 81               [ 4]   90 ret
                                     91 .area CODE
                                     92 .area CONST
      0080CA                         93 _HSIDivFactor:
      0080CA 01                      94 .db #0x01	; 1
      0080CB 02                      95 .db #0x02	; 2
      0080CC 04                      96 .db #0x04	; 4
      0080CD 08                      97 .db #0x08	; 8
                                     98 .area INITIALIZER
                                     99 .area CABS (ABS)
