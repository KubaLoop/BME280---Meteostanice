                                      1 .module stm8s_uart1
                                      2 .optsdcc -mstm8
                                      3 .globl _CLK_GetClockFreq
                                      4 .globl _UART1_DeInit
                                      5 .globl _UART1_SendData8
                                      6 .area DATA
                                      7 .area INITIALIZED
                                      8 .area DABS (ABS)
                                      9 .area HOME
                                     10 .area GSINIT
                                     11 .area GSFINAL
                                     12 .area CONST
                                     13 .area INITIALIZER
                                     14 .area CODE
                                     15 .area HOME
                                     16 .area GSINIT
                                     17 .area GSFINAL
                                     18 .area GSINIT
                                     19 .area HOME
                                     20 .area HOME
                                     21 .area CODE
      009146                         22 _UART1_DeInit:
      009146 C6 52 30         [ 1]   23 ld	a, 0x5230
      009149 C6 52 31         [ 1]   24 ld	a, 0x5231
      00914C 35 00 52 33      [ 1]   25 mov	0x5233+0, #0x00
      009150 35 00 52 32      [ 1]   26 mov	0x5232+0, #0x00
      009154 35 00 52 34      [ 1]   27 mov	0x5234+0, #0x00
      009158 35 00 52 35      [ 1]   28 mov	0x5235+0, #0x00
      00915C 35 00 52 36      [ 1]   29 mov	0x5236+0, #0x00
      009160 35 00 52 37      [ 1]   30 mov	0x5237+0, #0x00
      009164 35 00 52 38      [ 1]   31 mov	0x5238+0, #0x00
      009168 35 00 52 39      [ 1]   32 mov	0x5239+0, #0x00
      00916C 35 00 52 3A      [ 1]   33 mov	0x523a+0, #0x00
      009170                         34 00101$:
      009170 81               [ 4]   35 ret
      009171                         36 _UART1_SendData8:
      009171 C7 52 31         [ 1]   37 ld	0x5231, a
      009174                         38 00101$:
      009174 81               [ 4]   39 ret
                                     40 .area CODE
                                     41 .area CONST
                                     42 .area INITIALIZER
                                     43 .area CABS (ABS)
