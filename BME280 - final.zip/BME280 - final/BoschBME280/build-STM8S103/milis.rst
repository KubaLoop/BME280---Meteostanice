                                      1 .module milis
                                      2 .optsdcc -mstm8
                                      3 .globl _TIM4_ClearFlag
                                      4 .globl _TIM4_ITConfig
                                      5 .globl _TIM4_Cmd
                                      6 .globl _TIM4_TimeBaseInit
                                      7 .globl _ITC_SetSoftwarePriority
                                      8 .globl _miliseconds
                                      9 .globl _init_milis
                                     10 .area DATA
                                     11 .area INITIALIZED
      00001E                         12 _miliseconds::
      00001E                         13 .ds 4
                                     14 .area DABS (ABS)
                                     15 .area HOME
                                     16 .area GSINIT
                                     17 .area GSFINAL
                                     18 .area CONST
                                     19 .area INITIALIZER
                                     20 .area CODE
                                     21 .area HOME
                                     22 .area GSINIT
                                     23 .area GSFINAL
                                     24 .area GSINIT
                                     25 .area HOME
                                     26 .area HOME
                                     27 .area CODE
      008C08                         28 _init_milis:
      008C08 4B 7C            [ 1]   29 push	#0x7c
      008C0A A6 07            [ 1]   30 ld	a, #0x07
      008C0C CD 8D 73         [ 4]   31 call	_TIM4_TimeBaseInit
      008C0F A6 01            [ 1]   32 ld	a, #0x01
      008C11 CD 8D BD         [ 4]   33 call	_TIM4_ClearFlag
      008C14 4B 01            [ 1]   34 push	#0x01
      008C16 A6 01            [ 1]   35 ld	a, #0x01
      008C18 CD 8D 9B         [ 4]   36 call	_TIM4_ITConfig
      008C1B 4B 01            [ 1]   37 push	#0x01
      008C1D A6 17            [ 1]   38 ld	a, #0x17
      008C1F CD 8D C2         [ 4]   39 call	_ITC_SetSoftwarePriority
      008C22 9A               [ 1]   40 rim
      008C23 A6 01            [ 1]   41 ld	a, #0x01
      008C25 CC 8D 7F         [ 2]   42 jp	_TIM4_Cmd
      008C28                         43 00101$:
      008C28 81               [ 4]   44 ret
                                     45 .area CODE
                                     46 .area CONST
                                     47 .area INITIALIZER
      0080DB                         48 __xinit__miliseconds:
      0080DB 00 00 00 00             49 .byte #0x00, #0x00, #0x00, #0x00	; 0
                                     50 .area CABS (ABS)
