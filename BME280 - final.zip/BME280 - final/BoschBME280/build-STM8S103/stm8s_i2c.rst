                                      1 .module stm8s_i2c
                                      2 .optsdcc -mstm8
                                      3 .globl _I2C_DeInit
                                      4 .globl _I2C_Init
                                      5 .globl _I2C_Cmd
                                      6 .globl _I2C_GenerateSTART
                                      7 .globl _I2C_GenerateSTOP
                                      8 .globl _I2C_AcknowledgeConfig
                                      9 .globl _I2C_ReceiveData
                                     10 .globl _I2C_Send7bitAddress
                                     11 .globl _I2C_SendData
                                     12 .globl _I2C_CheckEvent
                                     13 .globl _I2C_GetFlagStatus
                                     14 .area DATA
                                     15 .area INITIALIZED
                                     16 .area DABS (ABS)
                                     17 .area HOME
                                     18 .area GSINIT
                                     19 .area GSFINAL
                                     20 .area CONST
                                     21 .area INITIALIZER
                                     22 .area CODE
                                     23 .area HOME
                                     24 .area GSINIT
                                     25 .area GSFINAL
                                     26 .area GSINIT
                                     27 .area HOME
                                     28 .area HOME
                                     29 .area CODE
      008EB4                         30 _I2C_DeInit:
      008EB4 35 00 52 10      [ 1]   31 mov	0x5210+0, #0x00
      008EB8 35 00 52 11      [ 1]   32 mov	0x5211+0, #0x00
      008EBC 35 00 52 12      [ 1]   33 mov	0x5212+0, #0x00
      008EC0 35 00 52 13      [ 1]   34 mov	0x5213+0, #0x00
      008EC4 35 00 52 14      [ 1]   35 mov	0x5214+0, #0x00
      008EC8 35 00 52 1A      [ 1]   36 mov	0x521a+0, #0x00
      008ECC 35 00 52 1B      [ 1]   37 mov	0x521b+0, #0x00
      008ED0 35 00 52 1C      [ 1]   38 mov	0x521c+0, #0x00
      008ED4 35 02 52 1D      [ 1]   39 mov	0x521d+0, #0x02
      008ED8                         40 00101$:
      008ED8 81               [ 4]   41 ret
      008ED9                         42 _I2C_Init:
      008ED9 52 05            [ 2]   43 sub	sp, #5
      008EDB 0F 05            [ 1]   44 clr	(0x05, sp)
      008EDD C6 52 12         [ 1]   45 ld	a, 0x5212
      008EE0 A4 C0            [ 1]   46 and	a, #0xc0
      008EE2 C7 52 12         [ 1]   47 ld	0x5212, a
      008EE5 C6 52 12         [ 1]   48 ld	a, 0x5212
      008EE8 1A 11            [ 1]   49 or	a, (0x11, sp)
      008EEA C7 52 12         [ 1]   50 ld	0x5212, a
      008EED C6 52 10         [ 1]   51 ld	a, 0x5210
      008EF0 A4 FE            [ 1]   52 and	a, #0xfe
      008EF2 C7 52 10         [ 1]   53 ld	0x5210, a
      008EF5 C6 52 1C         [ 1]   54 ld	a, 0x521c
      008EF8 A4 30            [ 1]   55 and	a, #0x30
      008EFA C7 52 1C         [ 1]   56 ld	0x521c, a
      008EFD C6 52 1B         [ 1]   57 ld	a, 0x521b
      008F00 35 00 52 1B      [ 1]   58 mov	0x521b+0, #0x00
      008F04 5F               [ 1]   59 clrw	x
      008F05 7B 11            [ 1]   60 ld	a, (0x11, sp)
      008F07 97               [ 1]   61 ld	xl, a
      008F08 90 5F            [ 1]   62 clrw	y
      008F0A 89               [ 2]   63 pushw	x
      008F0B 90 89            [ 2]   64 pushw	y
      008F0D 4B 40            [ 1]   65 push	#0x40
      008F0F 4B 42            [ 1]   66 push	#0x42
      008F11 4B 0F            [ 1]   67 push	#0x0f
      008F13 4B 00            [ 1]   68 push	#0x00
      008F15 CD 92 C9         [ 4]   69 call	__mullong
      008F18 5B 08            [ 2]   70 addw	sp, #8
      008F1A 1F 03            [ 2]   71 ldw	(0x03, sp), x
      008F1C 17 01            [ 2]   72 ldw	(0x01, sp), y
      008F1E AE 86 A0         [ 2]   73 ldw	x, #0x86a0
      008F21 13 0A            [ 2]   74 cpw	x, (0x0a, sp)
      008F23 A6 01            [ 1]   75 ld	a, #0x01
      008F25 12 09            [ 1]   76 sbc	a, (0x09, sp)
      008F27 4F               [ 1]   77 clr	a
      008F28 12 08            [ 1]   78 sbc	a, (0x08, sp)
      008F2A 25 03            [ 1]   79 jrc	00133$
      008F2C CC 8F B1         [ 2]   80 jp	00109$
      008F2F                         81 00133$:
      008F2F A6 80            [ 1]   82 ld	a, #0x80
      008F31 6B 05            [ 1]   83 ld	(0x05, sp), a
      008F33 0D 0E            [ 1]   84 tnz	(0x0e, sp)
      008F35 27 03            [ 1]   85 jreq	00134$
      008F37 CC 8F 5C         [ 2]   86 jp	00102$
      008F3A                         87 00134$:
      008F3A 1E 0A            [ 2]   88 ldw	x, (0x0a, sp)
      008F3C 89               [ 2]   89 pushw	x
      008F3D 1E 0A            [ 2]   90 ldw	x, (0x0a, sp)
      008F3F 89               [ 2]   91 pushw	x
      008F40 4B 03            [ 1]   92 push	#0x03
      008F42 5F               [ 1]   93 clrw	x
      008F43 89               [ 2]   94 pushw	x
      008F44 4B 00            [ 1]   95 push	#0x00
      008F46 CD 92 C9         [ 4]   96 call	__mullong
      008F49 5B 08            [ 2]   97 addw	sp, #8
      008F4B 89               [ 2]   98 pushw	x
      008F4C 90 89            [ 2]   99 pushw	y
      008F4E 1E 07            [ 2]  100 ldw	x, (0x07, sp)
      008F50 89               [ 2]  101 pushw	x
      008F51 1E 07            [ 2]  102 ldw	x, (0x07, sp)
      008F53 89               [ 2]  103 pushw	x
      008F54 CD 92 70         [ 4]  104 call	__divulong
      008F57 5B 08            [ 2]  105 addw	sp, #8
      008F59 CC 8F 84         [ 2]  106 jp	00103$
      008F5C                        107 00102$:
      008F5C 1E 0A            [ 2]  108 ldw	x, (0x0a, sp)
      008F5E 89               [ 2]  109 pushw	x
      008F5F 1E 0A            [ 2]  110 ldw	x, (0x0a, sp)
      008F61 89               [ 2]  111 pushw	x
      008F62 4B 19            [ 1]  112 push	#0x19
      008F64 5F               [ 1]  113 clrw	x
      008F65 89               [ 2]  114 pushw	x
      008F66 4B 00            [ 1]  115 push	#0x00
      008F68 CD 92 C9         [ 4]  116 call	__mullong
      008F6B 5B 08            [ 2]  117 addw	sp, #8
      008F6D 9F               [ 1]  118 ld	a, xl
      008F6E 88               [ 1]  119 push	a
      008F6F 9E               [ 1]  120 ld	a, xh
      008F70 88               [ 1]  121 push	a
      008F71 90 89            [ 2]  122 pushw	y
      008F73 1E 07            [ 2]  123 ldw	x, (0x07, sp)
      008F75 89               [ 2]  124 pushw	x
      008F76 1E 07            [ 2]  125 ldw	x, (0x07, sp)
      008F78 89               [ 2]  126 pushw	x
      008F79 CD 92 70         [ 4]  127 call	__divulong
      008F7C 5B 08            [ 2]  128 addw	sp, #8
      008F7E 7B 05            [ 1]  129 ld	a, (0x05, sp)
      008F80 AA 40            [ 1]  130 or	a, #0x40
      008F82 6B 05            [ 1]  131 ld	(0x05, sp), a
      008F84                        132 00103$:
      008F84 A3 00 01         [ 2]  133 cpw	x, #0x0001
      008F87 25 03            [ 1]  134 jrc	00135$
      008F89 CC 8F 8E         [ 2]  135 jp	00105$
      008F8C                        136 00135$:
      008F8C 5F               [ 1]  137 clrw	x
      008F8D 5C               [ 1]  138 incw	x
      008F8E                        139 00105$:
      008F8E 7B 11            [ 1]  140 ld	a, (0x11, sp)
      008F90 6B 04            [ 1]  141 ld	(0x04, sp), a
      008F92 0F 03            [ 1]  142 clr	(0x03, sp)
      008F94 89               [ 2]  143 pushw	x
      008F95 1E 05            [ 2]  144 ldw	x, (0x05, sp)
      008F97 58               [ 2]  145 sllw	x
      008F98 72 FB 05         [ 2]  146 addw	x, (0x05, sp)
      008F9B 51               [ 1]  147 exgw	x, y
      008F9C 85               [ 2]  148 popw	x
      008F9D 89               [ 2]  149 pushw	x
      008F9E 4B 0A            [ 1]  150 push	#0x0a
      008FA0 4B 00            [ 1]  151 push	#0x00
      008FA2 93               [ 1]  152 ldw	x, y
      008FA3 CD 93 45         [ 4]  153 call	__divsint
      008FA6 90 93            [ 1]  154 ldw	y, x
      008FA8 9F               [ 1]  155 ld	a, xl
      008FA9 85               [ 2]  156 popw	x
      008FAA 4C               [ 1]  157 inc	a
      008FAB C7 52 1D         [ 1]  158 ld	0x521d, a
      008FAE CC 8F D7         [ 2]  159 jp	00110$
      008FB1                        160 00109$:
      008FB1 1E 0A            [ 2]  161 ldw	x, (0x0a, sp)
      008FB3 16 08            [ 2]  162 ldw	y, (0x08, sp)
      008FB5 58               [ 2]  163 sllw	x
      008FB6 90 59            [ 2]  164 rlcw	y
      008FB8 89               [ 2]  165 pushw	x
      008FB9 90 89            [ 2]  166 pushw	y
      008FBB 1E 07            [ 2]  167 ldw	x, (0x07, sp)
      008FBD 89               [ 2]  168 pushw	x
      008FBE 1E 07            [ 2]  169 ldw	x, (0x07, sp)
      008FC0 89               [ 2]  170 pushw	x
      008FC1 CD 92 70         [ 4]  171 call	__divulong
      008FC4 5B 08            [ 2]  172 addw	sp, #8
      008FC6 A3 00 04         [ 2]  173 cpw	x, #0x0004
      008FC9 25 03            [ 1]  174 jrc	00136$
      008FCB CC 8F D1         [ 2]  175 jp	00107$
      008FCE                        176 00136$:
      008FCE AE 00 04         [ 2]  177 ldw	x, #0x0004
      008FD1                        178 00107$:
      008FD1 7B 11            [ 1]  179 ld	a, (0x11, sp)
      008FD3 4C               [ 1]  180 inc	a
      008FD4 C7 52 1D         [ 1]  181 ld	0x521d, a
      008FD7                        182 00110$:
      008FD7 9F               [ 1]  183 ld	a, xl
      008FD8 C7 52 1B         [ 1]  184 ld	0x521b, a
      008FDB 9E               [ 1]  185 ld	a, xh
      008FDC A4 0F            [ 1]  186 and	a, #0x0f
      008FDE 1A 05            [ 1]  187 or	a, (0x05, sp)
      008FE0 C7 52 1C         [ 1]  188 ld	0x521c, a
      008FE3 C6 52 10         [ 1]  189 ld	a, 0x5210
      008FE6 AA 01            [ 1]  190 or	a, #0x01
      008FE8 C7 52 10         [ 1]  191 ld	0x5210, a
      008FEB 7B 0F            [ 1]  192 ld	a, (0x0f, sp)
      008FED CD 90 64         [ 4]  193 call	_I2C_AcknowledgeConfig
      008FF0 7B 0D            [ 1]  194 ld	a, (0x0d, sp)
      008FF2 C7 52 13         [ 1]  195 ld	0x5213, a
      008FF5 7B 10            [ 1]  196 ld	a, (0x10, sp)
      008FF7 AA 40            [ 1]  197 or	a, #0x40
      008FF9 6B 05            [ 1]  198 ld	(0x05, sp), a
      008FFB 4F               [ 1]  199 clr	a
      008FFC 97               [ 1]  200 ld	xl, a
      008FFD 7B 0C            [ 1]  201 ld	a, (0x0c, sp)
      008FFF A4 03            [ 1]  202 and	a, #0x03
      009001 95               [ 1]  203 ld	xh, a
      009002 A6 80            [ 1]  204 ld	a, #0x80
      009004 62               [ 2]  205 div	x, a
      009005 9F               [ 1]  206 ld	a, xl
      009006 1A 05            [ 1]  207 or	a, (0x05, sp)
      009008 C7 52 14         [ 1]  208 ld	0x5214, a
      00900B                        209 00111$:
      00900B 1E 06            [ 2]  210 ldw	x, (6, sp)
      00900D 5B 11            [ 2]  211 addw	sp, #17
      00900F FC               [ 2]  212 jp	(x)
      009010                        213 _I2C_Cmd:
      009010 88               [ 1]  214 push	a
      009011 6B 01            [ 1]  215 ld	(0x01, sp), a
      009013 C6 52 10         [ 1]  216 ld	a, 0x5210
      009016 0D 01            [ 1]  217 tnz	(0x01, sp)
      009018 26 03            [ 1]  218 jrne	00111$
      00901A CC 90 25         [ 2]  219 jp	00102$
      00901D                        220 00111$:
      00901D AA 01            [ 1]  221 or	a, #0x01
      00901F C7 52 10         [ 1]  222 ld	0x5210, a
      009022 CC 90 2A         [ 2]  223 jp	00104$
      009025                        224 00102$:
      009025 A4 FE            [ 1]  225 and	a, #0xfe
      009027 C7 52 10         [ 1]  226 ld	0x5210, a
      00902A                        227 00104$:
      00902A 84               [ 1]  228 pop	a
      00902B 81               [ 4]  229 ret
      00902C                        230 _I2C_GenerateSTART:
      00902C 88               [ 1]  231 push	a
      00902D 6B 01            [ 1]  232 ld	(0x01, sp), a
      00902F C6 52 11         [ 1]  233 ld	a, 0x5211
      009032 0D 01            [ 1]  234 tnz	(0x01, sp)
      009034 26 03            [ 1]  235 jrne	00111$
      009036 CC 90 41         [ 2]  236 jp	00102$
      009039                        237 00111$:
      009039 AA 01            [ 1]  238 or	a, #0x01
      00903B C7 52 11         [ 1]  239 ld	0x5211, a
      00903E CC 90 46         [ 2]  240 jp	00104$
      009041                        241 00102$:
      009041 A4 FE            [ 1]  242 and	a, #0xfe
      009043 C7 52 11         [ 1]  243 ld	0x5211, a
      009046                        244 00104$:
      009046 84               [ 1]  245 pop	a
      009047 81               [ 4]  246 ret
      009048                        247 _I2C_GenerateSTOP:
      009048 88               [ 1]  248 push	a
      009049 6B 01            [ 1]  249 ld	(0x01, sp), a
      00904B C6 52 11         [ 1]  250 ld	a, 0x5211
      00904E 0D 01            [ 1]  251 tnz	(0x01, sp)
      009050 26 03            [ 1]  252 jrne	00111$
      009052 CC 90 5D         [ 2]  253 jp	00102$
      009055                        254 00111$:
      009055 AA 02            [ 1]  255 or	a, #0x02
      009057 C7 52 11         [ 1]  256 ld	0x5211, a
      00905A CC 90 62         [ 2]  257 jp	00104$
      00905D                        258 00102$:
      00905D A4 FD            [ 1]  259 and	a, #0xfd
      00905F C7 52 11         [ 1]  260 ld	0x5211, a
      009062                        261 00104$:
      009062 84               [ 1]  262 pop	a
      009063 81               [ 4]  263 ret
      009064                        264 _I2C_AcknowledgeConfig:
      009064 97               [ 1]  265 ld	xl, a
      009065 C6 52 11         [ 1]  266 ld	a, 0x5211
      009068 41               [ 1]  267 exg	a, xl
      009069 4D               [ 1]  268 tnz	a
      00906A 41               [ 1]  269 exg	a, xl
      00906B 27 03            [ 1]  270 jreq	00119$
      00906D CC 90 78         [ 2]  271 jp	00105$
      009070                        272 00119$:
      009070 A4 FB            [ 1]  273 and	a, #0xfb
      009072 C7 52 11         [ 1]  274 ld	0x5211, a
      009075 CC 90 99         [ 2]  275 jp	00107$
      009078                        276 00105$:
      009078 AA 04            [ 1]  277 or	a, #0x04
      00907A C7 52 11         [ 1]  278 ld	0x5211, a
      00907D C6 52 11         [ 1]  279 ld	a, 0x5211
      009080 88               [ 1]  280 push	a
      009081 9F               [ 1]  281 ld	a, xl
      009082 4A               [ 1]  282 dec	a
      009083 84               [ 1]  283 pop	a
      009084 26 03            [ 1]  284 jrne	00121$
      009086 CC 90 8C         [ 2]  285 jp	00122$
      009089                        286 00121$:
      009089 CC 90 94         [ 2]  287 jp	00102$
      00908C                        288 00122$:
      00908C A4 F7            [ 1]  289 and	a, #0xf7
      00908E C7 52 11         [ 1]  290 ld	0x5211, a
      009091 CC 90 99         [ 2]  291 jp	00107$
      009094                        292 00102$:
      009094 AA 08            [ 1]  293 or	a, #0x08
      009096 C7 52 11         [ 1]  294 ld	0x5211, a
      009099                        295 00107$:
      009099 81               [ 4]  296 ret
      00909A                        297 _I2C_ReceiveData:
      00909A C6 52 16         [ 1]  298 ld	a, 0x5216
      00909D                        299 00101$:
      00909D 81               [ 4]  300 ret
      00909E                        301 _I2C_Send7bitAddress:
      00909E A4 FE            [ 1]  302 and	a, #0xfe
      0090A0 1A 03            [ 1]  303 or	a, (0x03, sp)
      0090A2 C7 52 16         [ 1]  304 ld	0x5216, a
      0090A5                        305 00101$:
      0090A5 85               [ 2]  306 popw	x
      0090A6 84               [ 1]  307 pop	a
      0090A7 FC               [ 2]  308 jp	(x)
      0090A8                        309 _I2C_SendData:
      0090A8 C7 52 16         [ 1]  310 ld	0x5216, a
      0090AB                        311 00101$:
      0090AB 81               [ 4]  312 ret
      0090AC                        313 _I2C_CheckEvent:
      0090AC 52 06            [ 2]  314 sub	sp, #6
      0090AE 51               [ 1]  315 exgw	x, y
      0090AF 5F               [ 1]  316 clrw	x
      0090B0 1F 01            [ 2]  317 ldw	(0x01, sp), x
      0090B2 90 A3 00 04      [ 2]  318 cpw	y, #0x0004
      0090B6 26 03            [ 1]  319 jrne	00120$
      0090B8 CC 90 BE         [ 2]  320 jp	00121$
      0090BB                        321 00120$:
      0090BB CC 90 CA         [ 2]  322 jp	00102$
      0090BE                        323 00121$:
      0090BE C6 52 18         [ 1]  324 ld	a, 0x5218
      0090C1 A4 04            [ 1]  325 and	a, #0x04
      0090C3 5F               [ 1]  326 clrw	x
      0090C4 97               [ 1]  327 ld	xl, a
      0090C5 1F 01            [ 2]  328 ldw	(0x01, sp), x
      0090C7 CC 90 E1         [ 2]  329 jp	00103$
      0090CA                        330 00102$:
      0090CA C6 52 17         [ 1]  331 ld	a, 0x5217
      0090CD 97               [ 1]  332 ld	xl, a
      0090CE C6 52 19         [ 1]  333 ld	a, 0x5219
      0090D1 95               [ 1]  334 ld	xh, a
      0090D2 4F               [ 1]  335 clr	a
      0090D3 0F 04            [ 1]  336 clr	(0x04, sp)
      0090D5 9F               [ 1]  337 ld	a, xl
      0090D6 0F 05            [ 1]  338 clr	(0x05, sp)
      0090D8 1A 04            [ 1]  339 or	a, (0x04, sp)
      0090DA 97               [ 1]  340 ld	xl, a
      0090DB 9E               [ 1]  341 ld	a, xh
      0090DC 1A 05            [ 1]  342 or	a, (0x05, sp)
      0090DE 95               [ 1]  343 ld	xh, a
      0090DF 1F 01            [ 2]  344 ldw	(0x01, sp), x
      0090E1                        345 00103$:
      0090E1 90 9F            [ 1]  346 ld	a, yl
      0090E3 14 02            [ 1]  347 and	a, (0x02, sp)
      0090E5 6B 06            [ 1]  348 ld	(0x06, sp), a
      0090E7 90 9E            [ 1]  349 ld	a, yh
      0090E9 14 01            [ 1]  350 and	a, (0x01, sp)
      0090EB 6B 05            [ 1]  351 ld	(0x05, sp), a
      0090ED 93               [ 1]  352 ldw	x, y
      0090EE 13 05            [ 2]  353 cpw	x, (0x05, sp)
      0090F0 26 03            [ 1]  354 jrne	00123$
      0090F2 CC 90 F8         [ 2]  355 jp	00124$
      0090F5                        356 00123$:
      0090F5 CC 90 FD         [ 2]  357 jp	00105$
      0090F8                        358 00124$:
      0090F8 A6 01            [ 1]  359 ld	a, #0x01
      0090FA CC 90 FE         [ 2]  360 jp	00106$
      0090FD                        361 00105$:
      0090FD 4F               [ 1]  362 clr	a
      0090FE                        363 00106$:
      0090FE                        364 00107$:
      0090FE 5B 06            [ 2]  365 addw	sp, #6
      009100 81               [ 4]  366 ret
      009101                        367 _I2C_GetFlagStatus:
      009101 88               [ 1]  368 push	a
      009102 0F 01            [ 1]  369 clr	(0x01, sp)
      009104 90 93            [ 1]  370 ldw	y, x
      009106 9E               [ 1]  371 ld	a, xh
      009107 A1 01            [ 1]  372 cp	a, #0x01
      009109 26 03            [ 1]  373 jrne	00132$
      00910B CC 91 1F         [ 2]  374 jp	00101$
      00910E                        375 00132$:
      00910E A1 02            [ 1]  376 cp	a, #0x02
      009110 26 03            [ 1]  377 jrne	00135$
      009112 CC 91 27         [ 2]  378 jp	00102$
      009115                        379 00135$:
      009115 A1 03            [ 1]  380 cp	a, #0x03
      009117 26 03            [ 1]  381 jrne	00138$
      009119 CC 91 2F         [ 2]  382 jp	00103$
      00911C                        383 00138$:
      00911C CC 91 34         [ 2]  384 jp	00105$
      00911F                        385 00101$:
      00911F C6 52 17         [ 1]  386 ld	a, 0x5217
      009122 6B 01            [ 1]  387 ld	(0x01, sp), a
      009124 CC 91 34         [ 2]  388 jp	00105$
      009127                        389 00102$:
      009127 C6 52 18         [ 1]  390 ld	a, 0x5218
      00912A 6B 01            [ 1]  391 ld	(0x01, sp), a
      00912C CC 91 34         [ 2]  392 jp	00105$
      00912F                        393 00103$:
      00912F C6 52 19         [ 1]  394 ld	a, 0x5219
      009132 6B 01            [ 1]  395 ld	(0x01, sp), a
      009134                        396 00105$:
      009134 9F               [ 1]  397 ld	a, xl
      009135 14 01            [ 1]  398 and	a, (0x01, sp)
      009137 4D               [ 1]  399 tnz	a
      009138 26 03            [ 1]  400 jrne	00140$
      00913A CC 91 42         [ 2]  401 jp	00107$
      00913D                        402 00140$:
      00913D A6 01            [ 1]  403 ld	a, #0x01
      00913F CC 91 43         [ 2]  404 jp	00108$
      009142                        405 00107$:
      009142 4F               [ 1]  406 clr	a
      009143                        407 00108$:
      009143                        408 00109$:
      009143 5B 01            [ 2]  409 addw	sp, #1
      009145 81               [ 4]  410 ret
                                    411 .area CODE
                                    412 .area CONST
                                    413 .area INITIALIZER
                                    414 .area CABS (ABS)
