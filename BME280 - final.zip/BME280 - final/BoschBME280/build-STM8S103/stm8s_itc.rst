                                      1 .module stm8s_itc
                                      2 .optsdcc -mstm8
                                      3 .globl _ITC_SetSoftwarePriority
                                      4 .area DATA
                                      5 .area INITIALIZED
                                      6 .area DABS (ABS)
                                      7 .area HOME
                                      8 .area GSINIT
                                      9 .area GSFINAL
                                     10 .area CONST
                                     11 .area INITIALIZER
                                     12 .area CODE
                                     13 .area HOME
                                     14 .area GSINIT
                                     15 .area GSFINAL
                                     16 .area GSINIT
                                     17 .area HOME
                                     18 .area HOME
                                     19 .area CODE
      008DC2                         20 _ITC_SetSoftwarePriority:
      008DC2 89               [ 2]   21 pushw	x
      008DC3 97               [ 1]   22 ld	xl, a
      008DC4 9F               [ 1]   23 ld	a, xl
      008DC5 90 5F            [ 1]   24 clrw	y
      008DC7 A4 03            [ 1]   25 and	a, #0x03
      008DC9 95               [ 1]   26 ld	xh, a
      008DCA 4F               [ 1]   27 clr	a
      008DCB 9E               [ 1]   28 ld	a, xh
      008DCC 48               [ 1]   29 sll	a
      008DCD 95               [ 1]   30 ld	xh, a
      008DCE A6 03            [ 1]   31 ld	a, #0x03
      008DD0 88               [ 1]   32 push	a
      008DD1 9E               [ 1]   33 ld	a, xh
      008DD2 4D               [ 1]   34 tnz	a
      008DD3 27 05            [ 1]   35 jreq	00132$
      008DD5                         36 00131$:
      008DD5 08 01            [ 1]   37 sll	(1, sp)
      008DD7 4A               [ 1]   38 dec	a
      008DD8 26 FB            [ 1]   39 jrne	00131$
      008DDA                         40 00132$:
      008DDA 84               [ 1]   41 pop	a
      008DDB 43               [ 1]   42 cpl	a
      008DDC 6B 01            [ 1]   43 ld	(0x01, sp), a
      008DDE 7B 05            [ 1]   44 ld	a, (0x05, sp)
      008DE0 88               [ 1]   45 push	a
      008DE1 9E               [ 1]   46 ld	a, xh
      008DE2 4D               [ 1]   47 tnz	a
      008DE3 27 05            [ 1]   48 jreq	00134$
      008DE5                         49 00133$:
      008DE5 08 01            [ 1]   50 sll	(1, sp)
      008DE7 4A               [ 1]   51 dec	a
      008DE8 26 FB            [ 1]   52 jrne	00133$
      008DEA                         53 00134$:
      008DEA 84               [ 1]   54 pop	a
      008DEB 6B 02            [ 1]   55 ld	(0x02, sp), a
      008DED 9F               [ 1]   56 ld	a, xl
      008DEE A1 18            [ 1]   57 cp	a, #0x18
      008DF0 23 03            [ 2]   58 jrule	00135$
      008DF2 CC 8E B0         [ 2]   59 jp	00124$
      008DF5                         60 00135$:
      008DF5 4F               [ 1]   61 clr	a
      008DF6 95               [ 1]   62 ld	xh, a
      008DF7 58               [ 2]   63 sllw	x
      008DF8 DE 8D FC         [ 2]   64 ldw	x, (#00136$, x)
      008DFB FC               [ 2]   65 jp	(x)
      008DFC                         66 00136$:
      008DFC 8E 2E                   67 .dw	#00104$
      008DFE 8E 2E                   68 .dw	#00104$
      008E00 8E 2E                   69 .dw	#00104$
      008E02 8E 2E                   70 .dw	#00104$
      008E04 8E 41                   71 .dw	#00108$
      008E06 8E 41                   72 .dw	#00108$
      008E08 8E 41                   73 .dw	#00108$
      008E0A 8E 41                   74 .dw	#00108$
      008E0C 8E B0                   75 .dw	#00124$
      008E0E 8E B0                   76 .dw	#00124$
      008E10 8E 54                   77 .dw	#00110$
      008E12 8E 54                   78 .dw	#00110$
      008E14 8E 67                   79 .dw	#00114$
      008E16 8E 67                   80 .dw	#00114$
      008E18 8E 67                   81 .dw	#00114$
      008E1A 8E 67                   82 .dw	#00114$
      008E1C 8E 7A                   83 .dw	#00118$
      008E1E 8E 7A                   84 .dw	#00118$
      008E20 8E 7A                   85 .dw	#00118$
      008E22 8E 7A                   86 .dw	#00118$
      008E24 8E B0                   87 .dw	#00124$
      008E26 8E B0                   88 .dw	#00124$
      008E28 8E 8D                   89 .dw	#00120$
      008E2A 8E 8D                   90 .dw	#00120$
      008E2C 8E A0                   91 .dw	#00121$
      008E2E                         92 00104$:
      008E2E C6 7F 70         [ 1]   93 ld	a, 0x7f70
      008E31 14 01            [ 1]   94 and	a, (0x01, sp)
      008E33 C7 7F 70         [ 1]   95 ld	0x7f70, a
      008E36 C6 7F 70         [ 1]   96 ld	a, 0x7f70
      008E39 1A 02            [ 1]   97 or	a, (0x02, sp)
      008E3B C7 7F 70         [ 1]   98 ld	0x7f70, a
      008E3E CC 8E B0         [ 2]   99 jp	00124$
      008E41                        100 00108$:
      008E41 C6 7F 71         [ 1]  101 ld	a, 0x7f71
      008E44 14 01            [ 1]  102 and	a, (0x01, sp)
      008E46 C7 7F 71         [ 1]  103 ld	0x7f71, a
      008E49 C6 7F 71         [ 1]  104 ld	a, 0x7f71
      008E4C 1A 02            [ 1]  105 or	a, (0x02, sp)
      008E4E C7 7F 71         [ 1]  106 ld	0x7f71, a
      008E51 CC 8E B0         [ 2]  107 jp	00124$
      008E54                        108 00110$:
      008E54 C6 7F 72         [ 1]  109 ld	a, 0x7f72
      008E57 14 01            [ 1]  110 and	a, (0x01, sp)
      008E59 C7 7F 72         [ 1]  111 ld	0x7f72, a
      008E5C C6 7F 72         [ 1]  112 ld	a, 0x7f72
      008E5F 1A 02            [ 1]  113 or	a, (0x02, sp)
      008E61 C7 7F 72         [ 1]  114 ld	0x7f72, a
      008E64 CC 8E B0         [ 2]  115 jp	00124$
      008E67                        116 00114$:
      008E67 C6 7F 73         [ 1]  117 ld	a, 0x7f73
      008E6A 14 01            [ 1]  118 and	a, (0x01, sp)
      008E6C C7 7F 73         [ 1]  119 ld	0x7f73, a
      008E6F C6 7F 73         [ 1]  120 ld	a, 0x7f73
      008E72 1A 02            [ 1]  121 or	a, (0x02, sp)
      008E74 C7 7F 73         [ 1]  122 ld	0x7f73, a
      008E77 CC 8E B0         [ 2]  123 jp	00124$
      008E7A                        124 00118$:
      008E7A C6 7F 74         [ 1]  125 ld	a, 0x7f74
      008E7D 14 01            [ 1]  126 and	a, (0x01, sp)
      008E7F C7 7F 74         [ 1]  127 ld	0x7f74, a
      008E82 C6 7F 74         [ 1]  128 ld	a, 0x7f74
      008E85 1A 02            [ 1]  129 or	a, (0x02, sp)
      008E87 C7 7F 74         [ 1]  130 ld	0x7f74, a
      008E8A CC 8E B0         [ 2]  131 jp	00124$
      008E8D                        132 00120$:
      008E8D C6 7F 75         [ 1]  133 ld	a, 0x7f75
      008E90 14 01            [ 1]  134 and	a, (0x01, sp)
      008E92 C7 7F 75         [ 1]  135 ld	0x7f75, a
      008E95 C6 7F 75         [ 1]  136 ld	a, 0x7f75
      008E98 1A 02            [ 1]  137 or	a, (0x02, sp)
      008E9A C7 7F 75         [ 1]  138 ld	0x7f75, a
      008E9D CC 8E B0         [ 2]  139 jp	00124$
      008EA0                        140 00121$:
      008EA0 C6 7F 76         [ 1]  141 ld	a, 0x7f76
      008EA3 14 01            [ 1]  142 and	a, (0x01, sp)
      008EA5 C7 7F 76         [ 1]  143 ld	0x7f76, a
      008EA8 C6 7F 76         [ 1]  144 ld	a, 0x7f76
      008EAB 1A 02            [ 1]  145 or	a, (0x02, sp)
      008EAD C7 7F 76         [ 1]  146 ld	0x7f76, a
      008EB0                        147 00124$:
      008EB0 85               [ 2]  148 popw	x
      008EB1 85               [ 2]  149 popw	x
      008EB2 84               [ 1]  150 pop	a
      008EB3 FC               [ 2]  151 jp	(x)
                                    152 .area CODE
                                    153 .area CONST
                                    154 .area INITIALIZER
                                    155 .area CABS (ABS)
