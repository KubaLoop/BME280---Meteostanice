                                      1 .module main
                                      2 .optsdcc -mstm8
                                      3 .globl _main
                                      4 .globl _sprintf
                                      5 .globl _BoschWrite
                                      6 .globl _BoschHum
                                      7 .globl _BoschTemp
                                      8 .globl _bosch_Init
                                      9 .globl _LCD_I2C_Print
                                     10 .globl _LCD_I2C_SetCursor
                                     11 .globl _LCD_I2C_Clear
                                     12 .globl _LCD_I2C_Init
                                     13 .globl _delay_ms
                                     14 .globl _GPIO_WriteLow
                                     15 .globl _GPIO_WriteHigh
                                     16 .globl _GPIO_Init
                                     17 .globl _CLK_HSIPrescalerConfig
                                     18 .globl _setup
                                     19 .area DATA
                                     20 .area INITIALIZED
                                     21 .area	SSEG
      009981                         22 __start__stack:
      009981                         23 .ds	1
                                     24 .area DABS (ABS)
                                     25 .area HOME
                                     26 .area GSINIT
                                     27 .area GSFINAL
                                     28 .area CONST
                                     29 .area INITIALIZER
                                     30 .area CODE
                                     31 .area HOME
      008000                         32 __interrupt_vect:
      008000 82 00 80 6F             33 int s_GSINIT ; reset
      008004 82 00 8C 29             34 int _TRAP_IRQHandler ; trap
      008008 82 00 8C 2A             35 int _TLI_IRQHandler ; int0
      00800C 82 00 8C 2B             36 int _AWU_IRQHandler ; int1
      008010 82 00 8C 2C             37 int _CLK_IRQHandler ; int2
      008014 82 00 8C 2D             38 int _EXTI_PORTA_IRQHandler ; int3
      008018 82 00 8C 2E             39 int _EXTI_PORTB_IRQHandler ; int4
      00801C 82 00 8C 2F             40 int _EXTI_PORTC_IRQHandler ; int5
      008020 82 00 8C 30             41 int _EXTI_PORTD_IRQHandler ; int6
      008024 82 00 8C 31             42 int _EXTI_PORTE_IRQHandler ; int7
      008028 82 00 00 00             43 int 0x000000 ; int8
      00802C 82 00 00 00             44 int 0x000000 ; int9
      008030 82 00 8C 32             45 int _SPI_IRQHandler ; int10
      008034 82 00 8C 33             46 int _TIM1_UPD_OVF_TRG_BRK_IRQHandler ; int11
      008038 82 00 8C 34             47 int _TIM1_CAP_COM_IRQHandler ; int12
      00803C 82 00 8C 35             48 int _TIM2_UPD_OVF_BRK_IRQHandler ; int13
      008040 82 00 8C 36             49 int _TIM2_CAP_COM_IRQHandler ; int14
      008044 82 00 00 00             50 int 0x000000 ; int15
      008048 82 00 00 00             51 int 0x000000 ; int16
      00804C 82 00 8C 37             52 int _UART1_TX_IRQHandler ; int17
      008050 82 00 8C 38             53 int _UART1_RX_IRQHandler ; int18
      008054 82 00 8C 39             54 int _I2C_IRQHandler ; int19
      008058 82 00 00 00             55 int 0x000000 ; int20
      00805C 82 00 00 00             56 int 0x000000 ; int21
      008060 82 00 8C 3A             57 int _ADC1_IRQHandler ; int22
      008064 82 00 8C 3B             58 int _TIM4_UPD_OVF_IRQHandler ; int23
      008068 82 00 8C 55             59 int _EEPROM_EEC_IRQHandler ; int24
                                     60 .area HOME
                                     61 .area GSINIT
                                     62 .area GSFINAL
                                     63 .area GSINIT
      00806F                         64 __sdcc_init_data:
      00806F AE 00 1B         [ 2]   65 ldw x, #l_DATA
      008072 27 07            [ 1]   66 jreq	00002$
      008074                         67 00001$:
      008074 72 4F 00 00      [ 1]   68 clr (s_DATA - 1, x)
      008078 5A               [ 2]   69 decw x
      008079 26 F9            [ 1]   70 jrne	00001$
      00807B                         71 00002$:
      00807B AE 00 06         [ 2]   72 ldw	x, #l_INITIALIZER
      00807E 27 09            [ 1]   73 jreq	00004$
      008080                         74 00003$:
      008080 D6 80 D8         [ 1]   75 ld	a, (s_INITIALIZER - 1, x)
      008083 D7 00 1B         [ 1]   76 ld	(s_INITIALIZED - 1, x), a
      008086 5A               [ 2]   77 decw	x
      008087 26 F7            [ 1]   78 jrne	00003$
      008089                         79 00004$:
                                     80 .area GSFINAL
      008089 CC 80 6C         [ 2]   81 jp	__sdcc_program_startup
                                     82 .area HOME
                                     83 .area HOME
      00806C                         84 __sdcc_program_startup:
      00806C CC 8B 0B         [ 2]   85 jp	_main
                                     86 .area CODE
      008ABD                         87 _setup:
      008ABD 4F               [ 1]   88 clr	a
      008ABE CD 8C FF         [ 4]   89 call	_CLK_HSIPrescalerConfig
      008AC1 4B C0            [ 1]   90 push	#0xc0
      008AC3 A6 10            [ 1]   91 ld	a, #0x10
      008AC5 AE 50 0F         [ 2]   92 ldw	x, #0x500f
      008AC8 CD 8C 56         [ 4]   93 call	_GPIO_Init
      008ACB 4B 02            [ 1]   94 push	#0x02
      008ACD 4B 10            [ 1]   95 push	#0x10
      008ACF A6 27            [ 1]   96 ld	a, #0x27
      008AD1 CD 80 DF         [ 4]   97 call	_LCD_I2C_Init
      008AD4 A6 10            [ 1]   98 ld	a, #0x10
      008AD6 AE 50 0F         [ 2]   99 ldw	x, #0x500f
      008AD9 CD 8C E0         [ 4]  100 call	_GPIO_WriteHigh
      008ADC AE 80 8C         [ 2]  101 ldw	x, #(___str_0+0)
      008ADF CD 82 C3         [ 4]  102 call	_LCD_I2C_Print
      008AE2 4B 01            [ 1]  103 push	#0x01
      008AE4 4F               [ 1]  104 clr	a
      008AE5 CD 82 80         [ 4]  105 call	_LCD_I2C_SetCursor
      008AE8 AE 80 95         [ 2]  106 ldw	x, #(___str_1+0)
      008AEB CD 82 C3         [ 4]  107 call	_LCD_I2C_Print
      008AEE A6 77            [ 1]  108 ld	a, #0x77
      008AF0 CD 82 D6         [ 4]  109 call	_bosch_Init
      008AF3 4B E8            [ 1]  110 push	#0xe8
      008AF5 4B 03            [ 1]  111 push	#0x03
      008AF7 5F               [ 1]  112 clrw	x
      008AF8 89               [ 2]  113 pushw	x
      008AF9 CD 89 DC         [ 4]  114 call	_delay_ms
      008AFC 4B F2            [ 1]  115 push	#0xf2
      008AFE A6 05            [ 1]  116 ld	a, #0x05
      008B00 CD 89 7D         [ 4]  117 call	_BoschWrite
      008B03 4B F4            [ 1]  118 push	#0xf4
      008B05 A6 A0            [ 1]  119 ld	a, #0xa0
      008B07 CD 89 7D         [ 4]  120 call	_BoschWrite
      008B0A                        121 00101$:
      008B0A 81               [ 4]  122 ret
      008B0B                        123 _main:
      008B0B 52 74            [ 2]  124 sub	sp, #116
      008B0D CD 8A BD         [ 4]  125 call	_setup
      008B10                        126 00102$:
      008B10 A6 10            [ 1]  127 ld	a, #0x10
      008B12 AE 50 0F         [ 2]  128 ldw	x, #0x500f
      008B15 CD 8C E9         [ 4]  129 call	_GPIO_WriteLow
      008B18 4B F4            [ 1]  130 push	#0xf4
      008B1A A6 A1            [ 1]  131 ld	a, #0xa1
      008B1C CD 89 7D         [ 4]  132 call	_BoschWrite
      008B1F 4B E8            [ 1]  133 push	#0xe8
      008B21 4B 03            [ 1]  134 push	#0x03
      008B23 5F               [ 1]  135 clrw	x
      008B24 89               [ 2]  136 pushw	x
      008B25 CD 89 DC         [ 4]  137 call	_delay_ms
      008B28 CD 84 ED         [ 4]  138 call	_BoschTemp
      008B2B 1F 73            [ 2]  139 ldw	(0x73, sp), x
      008B2D 17 71            [ 2]  140 ldw	(0x71, sp), y
      008B2F 4B 64            [ 1]  141 push	#0x64
      008B31 5F               [ 1]  142 clrw	x
      008B32 89               [ 2]  143 pushw	x
      008B33 4B 00            [ 1]  144 push	#0x00
      008B35 1E 77            [ 2]  145 ldw	x, (0x77, sp)
      008B37 89               [ 2]  146 pushw	x
      008B38 1E 77            [ 2]  147 ldw	x, (0x77, sp)
      008B3A 89               [ 2]  148 pushw	x
      008B3B CD 91 75         [ 4]  149 call	__modslong
      008B3E 5B 08            [ 2]  150 addw	sp, #8
      008B40 1F 63            [ 2]  151 ldw	(0x63, sp), x
      008B42 17 61            [ 2]  152 ldw	(0x61, sp), y
      008B44 4B 64            [ 1]  153 push	#0x64
      008B46 5F               [ 1]  154 clrw	x
      008B47 89               [ 2]  155 pushw	x
      008B48 4B 00            [ 1]  156 push	#0x00
      008B4A 1E 77            [ 2]  157 ldw	x, (0x77, sp)
      008B4C 89               [ 2]  158 pushw	x
      008B4D 1E 77            [ 2]  159 ldw	x, (0x77, sp)
      008B4F 89               [ 2]  160 pushw	x
      008B50 CD 92 02         [ 4]  161 call	__divslong
      008B53 5B 08            [ 2]  162 addw	sp, #8
      008B55 4B 64            [ 1]  163 push	#0x64
      008B57 4B 00            [ 1]  164 push	#0x00
      008B59 4B 00            [ 1]  165 push	#0x00
      008B5B 4B 00            [ 1]  166 push	#0x00
      008B5D 89               [ 2]  167 pushw	x
      008B5E 90 89            [ 2]  168 pushw	y
      008B60 CD 91 75         [ 4]  169 call	__modslong
      008B63 5B 08            [ 2]  170 addw	sp, #8
      008B65 1F 67            [ 2]  171 ldw	(0x67, sp), x
      008B67 17 65            [ 2]  172 ldw	(0x65, sp), y
      008B69 CD 86 D5         [ 4]  173 call	_BoschHum
      008B6C 51               [ 1]  174 exgw	x, y
      008B6D 5E               [ 1]  175 swapw	x
      008B6E 90 9E            [ 1]  176 ld	a, yh
      008B70 88               [ 1]  177 push	a
      008B71 A4 03            [ 1]  178 and	a, #0x03
      008B73 6B 6C            [ 1]  179 ld	(0x6c, sp), a
      008B75 61               [ 1]  180 exg	a, yl
      008B76 6B 6D            [ 1]  181 ld	(0x6d, sp), a
      008B78 61               [ 1]  182 exg	a, yl
      008B79 0F 6B            [ 1]  183 clr	(0x6b, sp)
      008B7B 0F 6A            [ 1]  184 clr	(0x6a, sp)
      008B7D 84               [ 1]  185 pop	a
      008B7E 0F 6D            [ 1]  186 clr	(0x6d, sp)
      008B80 41               [ 1]  187 exg	a, xl
      008B81 44               [ 1]  188 srl	a
      008B82 41               [ 1]  189 exg	a, xl
      008B83 02               [ 1]  190 rlwa	x
      008B84 46               [ 1]  191 rrc	a
      008B85 01               [ 1]  192 rrwa	x
      008B86 46               [ 1]  193 rrc	a
      008B87 41               [ 1]  194 exg	a, xl
      008B88 44               [ 1]  195 srl	a
      008B89 41               [ 1]  196 exg	a, xl
      008B8A 02               [ 1]  197 rlwa	x
      008B8B 46               [ 1]  198 rrc	a
      008B8C 01               [ 1]  199 rrwa	x
      008B8D 46               [ 1]  200 rrc	a
      008B8E 6B 74            [ 1]  201 ld	(0x74, sp), a
      008B90 9E               [ 1]  202 ld	a, xh
      008B91 A4 03            [ 1]  203 and	a, #0x03
      008B93 6B 73            [ 1]  204 ld	(0x73, sp), a
      008B95 0F 72            [ 1]  205 clr	(0x72, sp)
      008B97 0F 71            [ 1]  206 clr	(0x71, sp)
      008B99 4B F4            [ 1]  207 push	#0xf4
      008B9B 4B 01            [ 1]  208 push	#0x01
      008B9D 5F               [ 1]  209 clrw	x
      008B9E 89               [ 2]  210 pushw	x
      008B9F CD 89 DC         [ 4]  211 call	_delay_ms
      008BA2 CD 82 62         [ 4]  212 call	_LCD_I2C_Clear
      008BA5 4B 00            [ 1]  213 push	#0x00
      008BA7 4F               [ 1]  214 clr	a
      008BA8 CD 82 80         [ 4]  215 call	_LCD_I2C_SetCursor
      008BAB 1E 63            [ 2]  216 ldw	x, (0x63, sp)
      008BAD 89               [ 2]  217 pushw	x
      008BAE 1E 63            [ 2]  218 ldw	x, (0x63, sp)
      008BB0 89               [ 2]  219 pushw	x
      008BB1 1E 6B            [ 2]  220 ldw	x, (0x6b, sp)
      008BB3 89               [ 2]  221 pushw	x
      008BB4 1E 6B            [ 2]  222 ldw	x, (0x6b, sp)
      008BB6 89               [ 2]  223 pushw	x
      008BB7 4B A2            [ 1]  224 push	#<(___str_2+0)
      008BB9 4B 80            [ 1]  225 push	#((___str_2+0) >> 8)
      008BBB 96               [ 1]  226 ldw	x, sp
      008BBC 1C 00 0B         [ 2]  227 addw	x, #11
      008BBF 89               [ 2]  228 pushw	x
      008BC0 CD 92 58         [ 4]  229 call	_sprintf
      008BC3 5B 0C            [ 2]  230 addw	sp, #12
      008BC5 96               [ 1]  231 ldw	x, sp
      008BC6 5C               [ 1]  232 incw	x
      008BC7 CD 82 C3         [ 4]  233 call	_LCD_I2C_Print
      008BCA 4B 01            [ 1]  234 push	#0x01
      008BCC 4F               [ 1]  235 clr	a
      008BCD CD 82 80         [ 4]  236 call	_LCD_I2C_SetCursor
      008BD0 1E 6B            [ 2]  237 ldw	x, (0x6b, sp)
      008BD2 89               [ 2]  238 pushw	x
      008BD3 1E 6B            [ 2]  239 ldw	x, (0x6b, sp)
      008BD5 89               [ 2]  240 pushw	x
      008BD6 1E 77            [ 2]  241 ldw	x, (0x77, sp)
      008BD8 89               [ 2]  242 pushw	x
      008BD9 1E 77            [ 2]  243 ldw	x, (0x77, sp)
      008BDB 89               [ 2]  244 pushw	x
      008BDC 4B B4            [ 1]  245 push	#<(___str_3+0)
      008BDE 4B 80            [ 1]  246 push	#((___str_3+0) >> 8)
      008BE0 96               [ 1]  247 ldw	x, sp
      008BE1 1C 00 3B         [ 2]  248 addw	x, #59
      008BE4 89               [ 2]  249 pushw	x
      008BE5 CD 92 58         [ 4]  250 call	_sprintf
      008BE8 5B 0C            [ 2]  251 addw	sp, #12
      008BEA 96               [ 1]  252 ldw	x, sp
      008BEB 1C 00 31         [ 2]  253 addw	x, #49
      008BEE CD 82 C3         [ 4]  254 call	_LCD_I2C_Print
      008BF1 A6 10            [ 1]  255 ld	a, #0x10
      008BF3 AE 50 0F         [ 2]  256 ldw	x, #0x500f
      008BF6 CD 8C E0         [ 4]  257 call	_GPIO_WriteHigh
      008BF9 4B B8            [ 1]  258 push	#0xb8
      008BFB 4B 0B            [ 1]  259 push	#0x0b
      008BFD 5F               [ 1]  260 clrw	x
      008BFE 89               [ 2]  261 pushw	x
      008BFF CD 89 DC         [ 4]  262 call	_delay_ms
      008C02 CC 8B 10         [ 2]  263 jp	00102$
      008C05                        264 00104$:
      008C05 5B 74            [ 2]  265 addw	sp, #116
      008C07 81               [ 4]  266 ret
                                    267 .area CODE
                                    268 .area CONST
                                    269 .area CONST
      00808C                        270 ___str_0:
      00808C 54 45 50 4C 4F 4D 45   271 .ascii "TEPLOMER"
             52
      008094 00                     272 .db 0x00
                                    273 .area CODE
                                    274 .area CONST
      008095                        275 ___str_1:
      008095 42 4F 53 43 48 20 42   276 .ascii "BOSCH BME280"
             4D 45 32 38 30
      0080A1 00                     277 .db 0x00
                                    278 .area CODE
                                    279 .area CONST
      0080A2                        280 ___str_2:
      0080A2 54 65 70 6C 6F 74 61   281 .ascii "Teplota= %li.%liC"
             3D 20 25 6C 69 2E 25
             6C 69 43
      0080B3 00                     282 .db 0x00
                                    283 .area CODE
                                    284 .area CONST
      0080B4                        285 ___str_3:
      0080B4 56 6C 68 6B 6F 73 74   286 .ascii "Vlhkost= %lu.%0.2lu%%"
             3D 20 25 6C 75 2E 25
             30 2E 32 6C 75 25 25
      0080C9 00                     287 .db 0x00
                                    288 .area CODE
                                    289 .area INITIALIZER
                                    290 .area CABS (ABS)
