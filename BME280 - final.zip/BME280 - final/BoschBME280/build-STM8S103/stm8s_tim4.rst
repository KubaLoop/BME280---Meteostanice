                                      1 .module stm8s_tim4
                                      2 .optsdcc -mstm8
                                      3 .globl _TIM4_TimeBaseInit
                                      4 .globl _TIM4_Cmd
                                      5 .globl _TIM4_ITConfig
                                      6 .globl _TIM4_ClearFlag
                                      7 .area DATA
                                      8 .area INITIALIZED
                                      9 .area DABS (ABS)
                                     10 .area HOME
                                     11 .area GSINIT
                                     12 .area GSFINAL
                                     13 .area CONST
                                     14 .area INITIALIZER
                                     15 .area CODE
                                     16 .area HOME
                                     17 .area GSINIT
                                     18 .area GSFINAL
                                     19 .area GSINIT
                                     20 .area HOME
                                     21 .area HOME
                                     22 .area CODE
      008D73                         23 _TIM4_TimeBaseInit:
      008D73 C7 53 47         [ 1]   24 ld	0x5347, a
      008D76 AE 53 48         [ 2]   25 ldw	x, #0x5348
      008D79 7B 03            [ 1]   26 ld	a, (0x03, sp)
      008D7B F7               [ 1]   27 ld	(x), a
      008D7C                         28 00101$:
      008D7C 85               [ 2]   29 popw	x
      008D7D 84               [ 1]   30 pop	a
      008D7E FC               [ 2]   31 jp	(x)
      008D7F                         32 _TIM4_Cmd:
      008D7F 88               [ 1]   33 push	a
      008D80 6B 01            [ 1]   34 ld	(0x01, sp), a
      008D82 C6 53 40         [ 1]   35 ld	a, 0x5340
      008D85 0D 01            [ 1]   36 tnz	(0x01, sp)
      008D87 26 03            [ 1]   37 jrne	00111$
      008D89 CC 8D 94         [ 2]   38 jp	00102$
      008D8C                         39 00111$:
      008D8C AA 01            [ 1]   40 or	a, #0x01
      008D8E C7 53 40         [ 1]   41 ld	0x5340, a
      008D91 CC 8D 99         [ 2]   42 jp	00104$
      008D94                         43 00102$:
      008D94 A4 FE            [ 1]   44 and	a, #0xfe
      008D96 C7 53 40         [ 1]   45 ld	0x5340, a
      008D99                         46 00104$:
      008D99 84               [ 1]   47 pop	a
      008D9A 81               [ 4]   48 ret
      008D9B                         49 _TIM4_ITConfig:
      008D9B 88               [ 1]   50 push	a
      008D9C AE 53 43         [ 2]   51 ldw	x, #0x5343
      008D9F 88               [ 1]   52 push	a
      008DA0 F6               [ 1]   53 ld	a, (x)
      008DA1 6B 02            [ 1]   54 ld	(0x02, sp), a
      008DA3 84               [ 1]   55 pop	a
      008DA4 0D 04            [ 1]   56 tnz	(0x04, sp)
      008DA6 26 03            [ 1]   57 jrne	00111$
      008DA8 CC 8D B3         [ 2]   58 jp	00102$
      008DAB                         59 00111$:
      008DAB 1A 01            [ 1]   60 or	a, (0x01, sp)
      008DAD C7 53 43         [ 1]   61 ld	0x5343, a
      008DB0 CC 8D B9         [ 2]   62 jp	00104$
      008DB3                         63 00102$:
      008DB3 43               [ 1]   64 cpl	a
      008DB4 14 01            [ 1]   65 and	a, (0x01, sp)
      008DB6 C7 53 43         [ 1]   66 ld	0x5343, a
      008DB9                         67 00104$:
      008DB9 84               [ 1]   68 pop	a
      008DBA 85               [ 2]   69 popw	x
      008DBB 84               [ 1]   70 pop	a
      008DBC FC               [ 2]   71 jp	(x)
      008DBD                         72 _TIM4_ClearFlag:
      008DBD 43               [ 1]   73 cpl	a
      008DBE C7 53 44         [ 1]   74 ld	0x5344, a
      008DC1                         75 00101$:
      008DC1 81               [ 4]   76 ret
                                     77 .area CODE
                                     78 .area CONST
                                     79 .area INITIALIZER
                                     80 .area CABS (ABS)
