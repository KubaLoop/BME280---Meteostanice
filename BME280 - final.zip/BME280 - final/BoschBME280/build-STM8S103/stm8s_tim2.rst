                                      1 .module stm8s_tim2
                                      2 .optsdcc -mstm8
                                      3 .area DATA
                                      4 .area INITIALIZED
                                      5 .area DABS (ABS)
                                      6 .area HOME
                                      7 .area GSINIT
                                      8 .area GSFINAL
                                      9 .area CONST
                                     10 .area INITIALIZER
                                     11 .area CODE
                                     12 .area HOME
                                     13 .area GSINIT
                                     14 .area GSFINAL
                                     15 .area GSINIT
                                     16 .area HOME
                                     17 .area HOME
                                     18 .area CODE
                                     19 .area CODE
                                     20 .area CONST
                                     21 .area INITIALIZER
                                     22 .area CABS (ABS)
