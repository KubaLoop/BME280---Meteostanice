                                      1 .module delay
                                      2 .optsdcc -mstm8
                                      3 .globl _CLK_GetClockFreq
                                      4 .globl _delay_ms
                                      5 .globl _delay_us
                                      6 .area DATA
                                      7 .area INITIALIZED
                                      8 .area DABS (ABS)
                                      9 .area HOME
                                     10 .area GSINIT
                                     11 .area GSFINAL
                                     12 .area CONST
                                     13 .area INITIALIZER
                                     14 .area CODE
                                     15 .area HOME
                                     16 .area GSINIT
                                     17 .area GSFINAL
                                     18 .area GSINIT
                                     19 .area HOME
                                     20 .area HOME
                                     21 .area CODE
      0089DC                         22 _delay_ms:
      0089DC 52 08            [ 2]   23 sub	sp, #8
      0089DE CD 8D 14         [ 4]   24 call	_CLK_GetClockFreq
      0089E1 1F 03            [ 2]   25 ldw	(0x03, sp), x
      0089E3 5F               [ 1]   26 clrw	x
      0089E4 1F 07            [ 2]   27 ldw	(0x07, sp), x
      0089E6 1F 05            [ 2]   28 ldw	(0x05, sp), x
      0089E8 4B 12            [ 1]   29 push	#0x12
      0089EA 5F               [ 1]   30 clrw	x
      0089EB 89               [ 2]   31 pushw	x
      0089EC 4B 00            [ 1]   32 push	#0x00
      0089EE 1E 07            [ 2]   33 ldw	x, (0x07, sp)
      0089F0 89               [ 2]   34 pushw	x
      0089F1 90 89            [ 2]   35 pushw	y
      0089F3 CD 92 70         [ 4]   36 call	__divulong
      0089F6 5B 08            [ 2]   37 addw	sp, #8
      0089F8 4B E8            [ 1]   38 push	#0xe8
      0089FA 4B 03            [ 1]   39 push	#0x03
      0089FC 4B 00            [ 1]   40 push	#0x00
      0089FE 4B 00            [ 1]   41 push	#0x00
      008A00 89               [ 2]   42 pushw	x
      008A01 90 89            [ 2]   43 pushw	y
      008A03 CD 92 70         [ 4]   44 call	__divulong
      008A06 5B 08            [ 2]   45 addw	sp, #8
      008A08 1F 03            [ 2]   46 ldw	(0x03, sp), x
      008A0A 1E 0D            [ 2]   47 ldw	x, (0x0d, sp)
      008A0C 89               [ 2]   48 pushw	x
      008A0D 1E 0D            [ 2]   49 ldw	x, (0x0d, sp)
      008A0F 89               [ 2]   50 pushw	x
      008A10 1E 07            [ 2]   51 ldw	x, (0x07, sp)
      008A12 89               [ 2]   52 pushw	x
      008A13 90 89            [ 2]   53 pushw	y
      008A15 CD 92 C9         [ 4]   54 call	__mullong
      008A18 5B 08            [ 2]   55 addw	sp, #8
      008A1A 1F 03            [ 2]   56 ldw	(0x03, sp), x
      008A1C 17 01            [ 2]   57 ldw	(0x01, sp), y
      008A1E                         58 00103$:
      008A1E 1E 07            [ 2]   59 ldw	x, (0x07, sp)
      008A20 13 03            [ 2]   60 cpw	x, (0x03, sp)
      008A22 7B 06            [ 1]   61 ld	a, (0x06, sp)
      008A24 12 02            [ 1]   62 sbc	a, (0x02, sp)
      008A26 7B 05            [ 1]   63 ld	a, (0x05, sp)
      008A28 12 01            [ 1]   64 sbc	a, (0x01, sp)
      008A2A 25 03            [ 1]   65 jrc	00118$
      008A2C CC 8A 3F         [ 2]   66 jp	00105$
      008A2F                         67 00118$:
      008A2F 9D               [ 1]   68 nop
      008A30 1E 07            [ 2]   69 ldw	x, (0x07, sp)
      008A32 5C               [ 1]   70 incw	x
      008A33 1F 07            [ 2]   71 ldw	(0x07, sp), x
      008A35 26 05            [ 1]   72 jrne	00119$
      008A37 1E 05            [ 2]   73 ldw	x, (0x05, sp)
      008A39 5C               [ 1]   74 incw	x
      008A3A 1F 05            [ 2]   75 ldw	(0x05, sp), x
      008A3C                         76 00119$:
      008A3C CC 8A 1E         [ 2]   77 jp	00103$
      008A3F                         78 00105$:
      008A3F 1E 09            [ 2]   79 ldw	x, (9, sp)
      008A41 5B 0E            [ 2]   80 addw	sp, #14
      008A43 FC               [ 2]   81 jp	(x)
      008A44                         82 _delay_us:
      008A44 52 08            [ 2]   83 sub	sp, #8
      008A46 CD 8D 14         [ 4]   84 call	_CLK_GetClockFreq
      008A49 1F 03            [ 2]   85 ldw	(0x03, sp), x
      008A4B 5F               [ 1]   86 clrw	x
      008A4C 1F 07            [ 2]   87 ldw	(0x07, sp), x
      008A4E 1F 05            [ 2]   88 ldw	(0x05, sp), x
      008A50 4B 12            [ 1]   89 push	#0x12
      008A52 5F               [ 1]   90 clrw	x
      008A53 89               [ 2]   91 pushw	x
      008A54 4B 00            [ 1]   92 push	#0x00
      008A56 1E 07            [ 2]   93 ldw	x, (0x07, sp)
      008A58 89               [ 2]   94 pushw	x
      008A59 90 89            [ 2]   95 pushw	y
      008A5B CD 92 70         [ 4]   96 call	__divulong
      008A5E 5B 08            [ 2]   97 addw	sp, #8
      008A60 4B E8            [ 1]   98 push	#0xe8
      008A62 4B 03            [ 1]   99 push	#0x03
      008A64 4B 00            [ 1]  100 push	#0x00
      008A66 4B 00            [ 1]  101 push	#0x00
      008A68 89               [ 2]  102 pushw	x
      008A69 90 89            [ 2]  103 pushw	y
      008A6B CD 92 70         [ 4]  104 call	__divulong
      008A6E 5B 08            [ 2]  105 addw	sp, #8
      008A70 1F 03            [ 2]  106 ldw	(0x03, sp), x
      008A72 17 01            [ 2]  107 ldw	(0x01, sp), y
      008A74 4B E8            [ 1]  108 push	#0xe8
      008A76 4B 03            [ 1]  109 push	#0x03
      008A78 5F               [ 1]  110 clrw	x
      008A79 89               [ 2]  111 pushw	x
      008A7A 1E 11            [ 2]  112 ldw	x, (0x11, sp)
      008A7C 89               [ 2]  113 pushw	x
      008A7D 1E 11            [ 2]  114 ldw	x, (0x11, sp)
      008A7F 89               [ 2]  115 pushw	x
      008A80 CD 92 70         [ 4]  116 call	__divulong
      008A83 5B 08            [ 2]  117 addw	sp, #8
      008A85 89               [ 2]  118 pushw	x
      008A86 90 89            [ 2]  119 pushw	y
      008A88 1E 07            [ 2]  120 ldw	x, (0x07, sp)
      008A8A 89               [ 2]  121 pushw	x
      008A8B 1E 07            [ 2]  122 ldw	x, (0x07, sp)
      008A8D 89               [ 2]  123 pushw	x
      008A8E CD 92 C9         [ 4]  124 call	__mullong
      008A91 5B 08            [ 2]  125 addw	sp, #8
      008A93 1F 03            [ 2]  126 ldw	(0x03, sp), x
      008A95 17 01            [ 2]  127 ldw	(0x01, sp), y
      008A97                        128 00103$:
      008A97 1E 07            [ 2]  129 ldw	x, (0x07, sp)
      008A99 13 03            [ 2]  130 cpw	x, (0x03, sp)
      008A9B 7B 06            [ 1]  131 ld	a, (0x06, sp)
      008A9D 12 02            [ 1]  132 sbc	a, (0x02, sp)
      008A9F 7B 05            [ 1]  133 ld	a, (0x05, sp)
      008AA1 12 01            [ 1]  134 sbc	a, (0x01, sp)
      008AA3 25 03            [ 1]  135 jrc	00118$
      008AA5 CC 8A B8         [ 2]  136 jp	00105$
      008AA8                        137 00118$:
      008AA8 9D               [ 1]  138 nop
      008AA9 1E 07            [ 2]  139 ldw	x, (0x07, sp)
      008AAB 5C               [ 1]  140 incw	x
      008AAC 1F 07            [ 2]  141 ldw	(0x07, sp), x
      008AAE 26 05            [ 1]  142 jrne	00119$
      008AB0 1E 05            [ 2]  143 ldw	x, (0x05, sp)
      008AB2 5C               [ 1]  144 incw	x
      008AB3 1F 05            [ 2]  145 ldw	(0x05, sp), x
      008AB5                        146 00119$:
      008AB5 CC 8A 97         [ 2]  147 jp	00103$
      008AB8                        148 00105$:
      008AB8 1E 09            [ 2]  149 ldw	x, (9, sp)
      008ABA 5B 0E            [ 2]  150 addw	sp, #14
      008ABC FC               [ 2]  151 jp	(x)
                                    152 .area CODE
                                    153 .area CONST
                                    154 .area INITIALIZER
                                    155 .area CABS (ABS)
