                                      1 .module stm8s_gpio
                                      2 .optsdcc -mstm8
                                      3 .globl _GPIO_Init
                                      4 .globl _GPIO_WriteHigh
                                      5 .globl _GPIO_WriteLow
                                      6 .globl _GPIO_ReadInputPin
                                      7 .area DATA
                                      8 .area INITIALIZED
                                      9 .area DABS (ABS)
                                     10 .area HOME
                                     11 .area GSINIT
                                     12 .area GSFINAL
                                     13 .area CONST
                                     14 .area INITIALIZER
                                     15 .area CODE
                                     16 .area HOME
                                     17 .area GSINIT
                                     18 .area GSFINAL
                                     19 .area GSINIT
                                     20 .area HOME
                                     21 .area HOME
                                     22 .area CODE
      008C56                         23 _GPIO_Init:
      008C56 52 06            [ 2]   24 sub	sp, #6
      008C58 51               [ 1]   25 exgw	x, y
      008C59 6B 06            [ 1]   26 ld	(0x06, sp), a
      008C5B 93               [ 1]   27 ldw	x, y
      008C5C 1C 00 04         [ 2]   28 addw	x, #0x0004
      008C5F 1F 01            [ 2]   29 ldw	(0x01, sp), x
      008C61 1E 01            [ 2]   30 ldw	x, (0x01, sp)
      008C63 F6               [ 1]   31 ld	a, (x)
      008C64 88               [ 1]   32 push	a
      008C65 7B 07            [ 1]   33 ld	a, (0x07, sp)
      008C67 43               [ 1]   34 cpl	a
      008C68 6B 04            [ 1]   35 ld	(0x04, sp), a
      008C6A 84               [ 1]   36 pop	a
      008C6B 14 03            [ 1]   37 and	a, (0x03, sp)
      008C6D 1E 01            [ 2]   38 ldw	x, (0x01, sp)
      008C6F F7               [ 1]   39 ld	(x), a
      008C70 93               [ 1]   40 ldw	x, y
      008C71 5C               [ 1]   41 incw	x
      008C72 5C               [ 1]   42 incw	x
      008C73 1F 04            [ 2]   43 ldw	(0x04, sp), x
      008C75 0D 09            [ 1]   44 tnz	(0x09, sp)
      008C77 2B 03            [ 1]   45 jrmi	00135$
      008C79 CC 8C 9F         [ 2]   46 jp	00105$
      008C7C                         47 00135$:
      008C7C 90 F6            [ 1]   48 ld	a, (y)
      008C7E 88               [ 1]   49 push	a
      008C7F 7B 0A            [ 1]   50 ld	a, (0x0a, sp)
      008C81 A5 10            [ 1]   51 bcp	a, #0x10
      008C83 84               [ 1]   52 pop	a
      008C84 26 03            [ 1]   53 jrne	00136$
      008C86 CC 8C 90         [ 2]   54 jp	00102$
      008C89                         55 00136$:
      008C89 1A 06            [ 1]   56 or	a, (0x06, sp)
      008C8B 90 F7            [ 1]   57 ld	(y), a
      008C8D CC 8C 94         [ 2]   58 jp	00103$
      008C90                         59 00102$:
      008C90 14 03            [ 1]   60 and	a, (0x03, sp)
      008C92 90 F7            [ 1]   61 ld	(y), a
      008C94                         62 00103$:
      008C94 1E 04            [ 2]   63 ldw	x, (0x04, sp)
      008C96 F6               [ 1]   64 ld	a, (x)
      008C97 1A 06            [ 1]   65 or	a, (0x06, sp)
      008C99 1E 04            [ 2]   66 ldw	x, (0x04, sp)
      008C9B F7               [ 1]   67 ld	(x), a
      008C9C CC 8C A7         [ 2]   68 jp	00106$
      008C9F                         69 00105$:
      008C9F 1E 04            [ 2]   70 ldw	x, (0x04, sp)
      008CA1 F6               [ 1]   71 ld	a, (x)
      008CA2 14 03            [ 1]   72 and	a, (0x03, sp)
      008CA4 1E 04            [ 2]   73 ldw	x, (0x04, sp)
      008CA6 F7               [ 1]   74 ld	(x), a
      008CA7                         75 00106$:
      008CA7 93               [ 1]   76 ldw	x, y
      008CA8 1C 00 03         [ 2]   77 addw	x, #0x0003
      008CAB F6               [ 1]   78 ld	a, (x)
      008CAC 88               [ 1]   79 push	a
      008CAD 7B 0A            [ 1]   80 ld	a, (0x0a, sp)
      008CAF A5 40            [ 1]   81 bcp	a, #0x40
      008CB1 84               [ 1]   82 pop	a
      008CB2 26 03            [ 1]   83 jrne	00137$
      008CB4 CC 8C BD         [ 2]   84 jp	00108$
      008CB7                         85 00137$:
      008CB7 1A 06            [ 1]   86 or	a, (0x06, sp)
      008CB9 F7               [ 1]   87 ld	(x), a
      008CBA CC 8C C0         [ 2]   88 jp	00109$
      008CBD                         89 00108$:
      008CBD 14 03            [ 1]   90 and	a, (0x03, sp)
      008CBF F7               [ 1]   91 ld	(x), a
      008CC0                         92 00109$:
      008CC0 1E 01            [ 2]   93 ldw	x, (0x01, sp)
      008CC2 F6               [ 1]   94 ld	a, (x)
      008CC3 88               [ 1]   95 push	a
      008CC4 7B 0A            [ 1]   96 ld	a, (0x0a, sp)
      008CC6 A5 20            [ 1]   97 bcp	a, #0x20
      008CC8 84               [ 1]   98 pop	a
      008CC9 26 03            [ 1]   99 jrne	00138$
      008CCB CC 8C D6         [ 2]  100 jp	00111$
      008CCE                        101 00138$:
      008CCE 1A 06            [ 1]  102 or	a, (0x06, sp)
      008CD0 1E 01            [ 2]  103 ldw	x, (0x01, sp)
      008CD2 F7               [ 1]  104 ld	(x), a
      008CD3 CC 8C DB         [ 2]  105 jp	00113$
      008CD6                        106 00111$:
      008CD6 14 03            [ 1]  107 and	a, (0x03, sp)
      008CD8 1E 01            [ 2]  108 ldw	x, (0x01, sp)
      008CDA F7               [ 1]  109 ld	(x), a
      008CDB                        110 00113$:
      008CDB 5B 06            [ 2]  111 addw	sp, #6
      008CDD 85               [ 2]  112 popw	x
      008CDE 84               [ 1]  113 pop	a
      008CDF FC               [ 2]  114 jp	(x)
      008CE0                        115 _GPIO_WriteHigh:
      008CE0 88               [ 1]  116 push	a
      008CE1 6B 01            [ 1]  117 ld	(0x01, sp), a
      008CE3 F6               [ 1]  118 ld	a, (x)
      008CE4 1A 01            [ 1]  119 or	a, (0x01, sp)
      008CE6 F7               [ 1]  120 ld	(x), a
      008CE7                        121 00101$:
      008CE7 84               [ 1]  122 pop	a
      008CE8 81               [ 4]  123 ret
      008CE9                        124 _GPIO_WriteLow:
      008CE9 88               [ 1]  125 push	a
      008CEA 88               [ 1]  126 push	a
      008CEB F6               [ 1]  127 ld	a, (x)
      008CEC 6B 02            [ 1]  128 ld	(0x02, sp), a
      008CEE 84               [ 1]  129 pop	a
      008CEF 43               [ 1]  130 cpl	a
      008CF0 14 01            [ 1]  131 and	a, (0x01, sp)
      008CF2 F7               [ 1]  132 ld	(x), a
      008CF3                        133 00101$:
      008CF3 84               [ 1]  134 pop	a
      008CF4 81               [ 4]  135 ret
      008CF5                        136 _GPIO_ReadInputPin:
      008CF5 88               [ 1]  137 push	a
      008CF6 6B 01            [ 1]  138 ld	(0x01, sp), a
      008CF8 E6 01            [ 1]  139 ld	a, (0x1, x)
      008CFA 14 01            [ 1]  140 and	a, (0x01, sp)
      008CFC                        141 00101$:
      008CFC 5B 01            [ 2]  142 addw	sp, #1
      008CFE 81               [ 4]  143 ret
                                    144 .area CODE
                                    145 .area CONST
                                    146 .area INITIALIZER
                                    147 .area CABS (ABS)
