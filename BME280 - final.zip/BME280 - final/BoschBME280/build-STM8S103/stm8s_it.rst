                                      1 .module stm8s_it
                                      2 .optsdcc -mstm8
                                      3 .globl _TIM4_ClearFlag
                                      4 .globl _TRAP_IRQHandler
                                      5 .globl _TLI_IRQHandler
                                      6 .globl _AWU_IRQHandler
                                      7 .globl _CLK_IRQHandler
                                      8 .globl _EXTI_PORTA_IRQHandler
                                      9 .globl _EXTI_PORTB_IRQHandler
                                     10 .globl _EXTI_PORTC_IRQHandler
                                     11 .globl _EXTI_PORTD_IRQHandler
                                     12 .globl _EXTI_PORTE_IRQHandler
                                     13 .globl _SPI_IRQHandler
                                     14 .globl _TIM1_UPD_OVF_TRG_BRK_IRQHandler
                                     15 .globl _TIM1_CAP_COM_IRQHandler
                                     16 .globl _TIM2_UPD_OVF_BRK_IRQHandler
                                     17 .globl _TIM2_CAP_COM_IRQHandler
                                     18 .globl _UART1_TX_IRQHandler
                                     19 .globl _UART1_RX_IRQHandler
                                     20 .globl _I2C_IRQHandler
                                     21 .globl _ADC1_IRQHandler
                                     22 .globl _TIM4_UPD_OVF_IRQHandler
                                     23 .globl _EEPROM_EEC_IRQHandler
                                     24 .area DATA
                                     25 .area INITIALIZED
                                     26 .area DABS (ABS)
                                     27 .area HOME
                                     28 .area GSINIT
                                     29 .area GSFINAL
                                     30 .area CONST
                                     31 .area INITIALIZER
                                     32 .area CODE
                                     33 .area HOME
                                     34 .area GSINIT
                                     35 .area GSFINAL
                                     36 .area GSINIT
                                     37 .area HOME
                                     38 .area HOME
                                     39 .area CODE
      008C29                         40 _TRAP_IRQHandler:
      008C29                         41 00101$:
      008C29 80               [11]   42 iret
      008C2A                         43 _TLI_IRQHandler:
      008C2A                         44 00101$:
      008C2A 80               [11]   45 iret
      008C2B                         46 _AWU_IRQHandler:
      008C2B                         47 00101$:
      008C2B 80               [11]   48 iret
      008C2C                         49 _CLK_IRQHandler:
      008C2C                         50 00101$:
      008C2C 80               [11]   51 iret
      008C2D                         52 _EXTI_PORTA_IRQHandler:
      008C2D                         53 00101$:
      008C2D 80               [11]   54 iret
      008C2E                         55 _EXTI_PORTB_IRQHandler:
      008C2E                         56 00101$:
      008C2E 80               [11]   57 iret
      008C2F                         58 _EXTI_PORTC_IRQHandler:
      008C2F                         59 00101$:
      008C2F 80               [11]   60 iret
      008C30                         61 _EXTI_PORTD_IRQHandler:
      008C30                         62 00101$:
      008C30 80               [11]   63 iret
      008C31                         64 _EXTI_PORTE_IRQHandler:
      008C31                         65 00101$:
      008C31 80               [11]   66 iret
      008C32                         67 _SPI_IRQHandler:
      008C32                         68 00101$:
      008C32 80               [11]   69 iret
      008C33                         70 _TIM1_UPD_OVF_TRG_BRK_IRQHandler:
      008C33                         71 00101$:
      008C33 80               [11]   72 iret
      008C34                         73 _TIM1_CAP_COM_IRQHandler:
      008C34                         74 00101$:
      008C34 80               [11]   75 iret
      008C35                         76 _TIM2_UPD_OVF_BRK_IRQHandler:
      008C35                         77 00101$:
      008C35 80               [11]   78 iret
      008C36                         79 _TIM2_CAP_COM_IRQHandler:
      008C36                         80 00101$:
      008C36 80               [11]   81 iret
      008C37                         82 _UART1_TX_IRQHandler:
      008C37                         83 00101$:
      008C37 80               [11]   84 iret
      008C38                         85 _UART1_RX_IRQHandler:
      008C38                         86 00101$:
      008C38 80               [11]   87 iret
      008C39                         88 _I2C_IRQHandler:
      008C39                         89 00101$:
      008C39 80               [11]   90 iret
      008C3A                         91 _ADC1_IRQHandler:
      008C3A                         92 00101$:
      008C3A 80               [11]   93 iret
      008C3B                         94 _TIM4_UPD_OVF_IRQHandler:
      008C3B 62               [ 2]   95 div	x, a
      008C3C A6 01            [ 1]   96 ld	a, #0x01
      008C3E CD 8D BD         [ 4]   97 call	_TIM4_ClearFlag
      008C41 CE 00 20         [ 2]   98 ldw	x, _miliseconds+2
      008C44 90 CE 00 1E      [ 2]   99 ldw	y, _miliseconds+0
      008C48 5C               [ 1]  100 incw	x
      008C49 26 02            [ 1]  101 jrne	00103$
      008C4B 90 5C            [ 1]  102 incw	y
      008C4D                        103 00103$:
      008C4D CF 00 20         [ 2]  104 ldw	_miliseconds+2, x
      008C50 90 CF 00 1E      [ 2]  105 ldw	_miliseconds+0, y
      008C54                        106 00101$:
      008C54 80               [11]  107 iret
      008C55                        108 _EEPROM_EEC_IRQHandler:
      008C55                        109 00101$:
      008C55 80               [11]  110 iret
                                    111 .area CODE
                                    112 .area CONST
                                    113 .area INITIALIZER
                                    114 .area CABS (ABS)
