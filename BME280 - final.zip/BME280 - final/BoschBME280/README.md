STM8 (SPŠE Deroboard) toolchain
================================

* Toto je startovací strom zdrojových kódů pro výuku Mikroprocesorové techniky
pro kit [STM8S Dero-board](https://gitlab.com/wykys/stm8s-dero-board).

* Jde o zjednodušenou verzi [našeho
toolchainu](https://github.com/spseol/STM8S-toolchain) pro µprocesor STM8S103F3.

* Platí tedy vše, co je popsáno v [původním
README](https://github.com/spseol/STM8S-toolchain/blob/main/README.md) ale tento toolchain obsahuje pouze `sdcc-gas` a `sdccrm`, na který se automaticky nastaví, při prvním zavolání `make`.

Další informace
-------------------

* [původním README](https://github.com/spseol/STM8S-toolchain/blob/main/README.md) 
