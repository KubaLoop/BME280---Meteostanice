#include "stm8s.h"
#include "delay.h"
#include "bosch.h"
#include "main.h"

uint8_t _bosch_address;

uint8_t _bosch_tempcalib[6];
uint8_t _bosch_humcalib[9];
int32_t t_fine;
bool _bosch_hastempcalib = FALSE;
bool _bosch_hashumcalib = FALSE;

void bosch_Init(uint8_t address){
    _bosch_address = address << 1;

    I2C_Init(100000, 0x00, I2C_DUTYCYCLE_2, I2C_ACK_CURR, I2C_ADDMODE_7BIT, CLK_GetClockFreq() / 1000000);
    I2C_Cmd(ENABLE);

    delay_ms(50);
}

void bosch_ReadTemp(uint8_t *buffer){
    uint8_t bytesToRead = 3;
    while (I2C_GetFlagStatus(I2C_FLAG_BUSBUSY))
        ;

    I2C_GenerateSTART(ENABLE);
    while (!I2C_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT))
        ;

    I2C_Send7bitAddress(_bosch_address, I2C_DIRECTION_TX);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
        ;

    I2C_SendData(0xFA);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_BYTE_TRANSMITTED))
        ;

    I2C_GenerateSTART(ENABLE);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT))
        ;

    I2C_Send7bitAddress(_bosch_address, I2C_DIRECTION_RX);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))
        ;

    while (bytesToRead)
    {
        while (!I2C_GetFlagStatus(I2C_FLAG_TRANSFERFINISHED));
        *buffer = I2C_ReceiveData();
        buffer++;
        bytesToRead--;

    }
            /* Clear ACK */
        I2C_AcknowledgeConfig(I2C_ACK_NONE);
        I2C_GenerateSTOP(ENABLE);
}



void bosch_ReadTempCalib(uint8_t *buffer2){
    uint8_t bytesToRead = 6;

    while (I2C_GetFlagStatus(I2C_FLAG_BUSBUSY))
        ;

    I2C_GenerateSTART(ENABLE);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT))
        ;

    I2C_Send7bitAddress(_bosch_address, I2C_DIRECTION_TX);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
        ;

    I2C_SendData(0x88);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_BYTE_TRANSMITTED))
        ;

    I2C_GenerateSTART(ENABLE);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT))
        ;

    I2C_Send7bitAddress(_bosch_address, I2C_DIRECTION_RX);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))
        ;

    while (bytesToRead)
    {
        while (!I2C_GetFlagStatus(I2C_FLAG_TRANSFERFINISHED));
        *buffer2 = I2C_ReceiveData();
        buffer2++;
        bytesToRead--;

    }
            /* Clear ACK */
        I2C_AcknowledgeConfig(I2C_ACK_NONE);
        I2C_GenerateSTOP(ENABLE);
}
uint8_t bosch_ReadReg(uint8_t reg_adr){
    uint8_t bytesToRead = 1;
    uint8_t regdata;
    while (I2C_GetFlagStatus(I2C_FLAG_BUSBUSY))
        ;

    I2C_GenerateSTART(ENABLE);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT))
        ;

    I2C_Send7bitAddress(_bosch_address, I2C_DIRECTION_TX);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
        ;

    I2C_SendData(reg_adr);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_BYTE_TRANSMITTED))
        ;

    I2C_GenerateSTART(ENABLE);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT))
        ;

    I2C_Send7bitAddress(_bosch_address, I2C_DIRECTION_RX);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))
        ;

    while (bytesToRead)
    {
        while (!I2C_GetFlagStatus(I2C_FLAG_TRANSFERFINISHED));
        regdata = I2C_ReceiveData();
        bytesToRead--;
    }
            /* Clear ACK */
        I2C_AcknowledgeConfig(I2C_ACK_NONE);
        I2C_GenerateSTOP(ENABLE);
        return regdata;
}
uint32_t BoschTemp(){
    uint8_t buffer[3];
    uint16_t dig_T1;
    int16_t dig_T2;
    int16_t dig_T3;
    uint8_t temp_msb, temp_lsb, temp_xlsb;

    if (!_bosch_hastempcalib){
    bosch_ReadTempCalib(_bosch_tempcalib);
    _bosch_hastempcalib = TRUE;
    }
    dig_T1 = ((uint16_t)_bosch_tempcalib[1] << 8) | _bosch_tempcalib[0];
    dig_T2 = ((int16_t)_bosch_tempcalib[3] << 8) | _bosch_tempcalib[2];
    dig_T3 = ((int16_t)_bosch_tempcalib[5] << 8) | _bosch_tempcalib[4];
    
    bosch_ReadTemp(buffer);
    temp_msb = buffer[0];
    temp_lsb = buffer[1];
    temp_xlsb = buffer[2];

    // Compensation formula pro teplotu
    int32_t adc_T = ((int32_t)temp_msb << 12) | ((int32_t)temp_lsb << 4) | ((int32_t)temp_xlsb >> 4);

    int32_t var1 = ((((adc_T >> 3) - ((int32_t)dig_T1 << 1))) * ((int32_t)dig_T2)) >> 11;
    int32_t var2 = (((((adc_T >> 4) - ((int32_t)dig_T1)) * ((adc_T >> 4) - ((int32_t)dig_T1))) >> 12) * ((int32_t)dig_T3)) >> 14;
    t_fine = var1 + var2;

    int32_t temperature = (t_fine * 5 + 128) >> 8;
    return temperature;

}
uint32_t BoschHum(){
    uint8_t dig_H1 = bosch_ReadReg(0xA1);
    int16_t dig_H2 = (int16_t)((bosch_ReadReg(0xE1) << 8) | bosch_ReadReg(0xE2));
    uint8_t dig_H3 = bosch_ReadReg(0xE3);
    int16_t dig_H4 = (int16_t)((bosch_ReadReg(0xE4) << 4) | (bosch_ReadReg(0xE5) & 0xF));
    int16_t dig_H5 = (int16_t)((bosch_ReadReg(0xE6) << 4) | bosch_ReadReg(0xE5) >> 4);
    int8_t dig_H6 = (int8_t)bosch_ReadReg(0xE7);
    uint8_t hum_msb = bosch_ReadReg(0xFD);
    uint8_t hum_lsb = bosch_ReadReg(0xFE);
    uint32_t humidity;
    int32_t adc_H = ((uint16_t)hum_msb << 8) | hum_lsb;
    if (adc_H == 0x8000) // value in case humidity measurement was disabled
    return 999999;
    //Compensation formula pro vlhkost
    int32_t v_x1_u32r = (t_fine - ((int32_t)76800));
    v_x1_u32r = (((((adc_H << 14) - ((int32_t)dig_H4 << 20) - ((int32_t)dig_H5 * v_x1_u32r)) + ((int32_t)16384)) >> 15) * (((((((v_x1_u32r * ((int32_t)dig_H6)) >> 10) * (((v_x1_u32r * ((int32_t)dig_H3)) >> 11) + ((int32_t)32768))) >> 10) + ((int32_t)2097152)) * ((int32_t)dig_H2) + 8192) >> 14));
    v_x1_u32r = (v_x1_u32r - (((((v_x1_u32r >> 15) * (v_x1_u32r >> 15)) >> 7) * ((int32_t)dig_H1)) >> 4));
    v_x1_u32r = (v_x1_u32r < 0 ? 0 : v_x1_u32r);
    v_x1_u32r = (v_x1_u32r > 419430400 ? 419430400 : v_x1_u32r);
    humidity = (uint32_t)(v_x1_u32r >> 12);
    return humidity;
}

void BoschWrite(uint8_t data, uint8_t reg_adr){
    uint8_t control_reg_value = data;
    while (I2C_GetFlagStatus(I2C_FLAG_BUSBUSY))
        ;

    I2C_GenerateSTART(ENABLE);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT))
        ;

    I2C_Send7bitAddress(_bosch_address, I2C_DIRECTION_TX);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
        ;

    I2C_SendData(reg_adr);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_BYTE_TRANSMITTED))
        ;
    I2C_SendData(control_reg_value);

    while (!I2C_CheckEvent(I2C_EVENT_MASTER_BYTE_TRANSMITTED))
        ;
    
    I2C_GenerateSTOP(ENABLE);
}
