#include "stm8s.h"
#include "delay.h"
#include "LCD_I2C.h" //knihovna pro LCD
#include "main.h" //makra pro main program
#include "bosch.h" //knihovna pro snímač BME280
#include <stdio.h> //knihovna pro použití funkce sprintf

#define BME280_ADDRESS 0x77 // BME280 Adresa (0x76 je nastavitelná na snímači)

//Main program měří a ukazuje teplotu a vlhkost na LCD displeji a tuto hodnotu refreshuje každych cca 5 sekund

void setup(void)
{
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
    GPIO_Init(LED_PORT, LED_PIN, GPIO_MODE_OUT_PP_LOW_SLOW);
    LCD_I2C_Init(0x27, 16, 2);          // Inicializace LCD
    HIGH(LED);
    LCD_I2C_Print("TEPLOMER"); // Úvodní obrazovka na displej
    LCD_I2C_SetCursor(0,1);
    LCD_I2C_Print("BOSCH BME280");
    bosch_Init(BME280_ADDRESS);
    delay_ms(1000);
    BoschWrite(0x05, 0xF2); //Nastaví oversampling pro vlhkost x16
}

// Main program
int main(void)
{
    setup();
    while (1)
    {
        LOW(LED);
        BoschWrite(0b10100001, 0xF4); //MSB 4 bity = oversampling x16 pro teplotu, LSB 2 bity = status sensoru (00=sleepmode) (01/10=forced mode)
        delay_ms(1000);
        char buffer3[48];
        char buffer4[48];
        int32_t actual_temperature = BoschTemp();
        int32_t tempdig1 = actual_temperature % 100;
        int32_t tempdig2 = (actual_temperature / 100) % 100;
        uint32_t actual_humidity = BoschHum();
        uint32_t humdig1 = actual_humidity % 1024;
        uint32_t humdig2 = (actual_humidity / 1024) % 1024;
        delay_ms(500);
        LCD_I2C_Clear(); 
        LCD_I2C_SetCursor(0, 0); // Nastavení kurzoru
        sprintf(buffer3, "Teplota= %li.%liC", tempdig2, tempdig1);
        LCD_I2C_Print(buffer3);
        LCD_I2C_SetCursor(0, 1);
        sprintf(buffer4, "Vlhkost= %lu.%0.2lu%%", humdig2, humdig1);
        LCD_I2C_Print(buffer4);
        HIGH(LED);
        delay_ms(3000);
    }
}