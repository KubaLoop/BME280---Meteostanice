#ifndef __DELAY_H
#define __DELAY_H

void delay_cycles(uint32_t value);
void delay_ms(uint32_t ms);
void delay_us(uint32_t us);

#endif /* __DELAY_H */