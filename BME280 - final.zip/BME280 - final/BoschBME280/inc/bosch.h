#ifndef __BOSCH_H
#define __BOSCH_H

extern uint8_t _bosch_address;
extern uint8_t _bosch_tempcalib[6];
extern bool _bosch_hastempcalib;
extern bool _bosch_hashumcalib;
extern int32_t t_fine;
void bosch_Init(uint8_t address);
void bosch_ReadTemp(uint8_t *buffer);
void bosch_ReadTempCalib(uint8_t *buffer2);
uint8_t bosch_ReadReg(uint8_t reg_adr);
uint32_t BoschTemp();
uint32_t BoschHum();
void BoschWrite(uint8_t data, uint8_t reg_adr);

#endif